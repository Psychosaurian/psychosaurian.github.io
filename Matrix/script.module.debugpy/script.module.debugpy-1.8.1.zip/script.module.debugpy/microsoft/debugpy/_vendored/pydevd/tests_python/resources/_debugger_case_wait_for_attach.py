if __name__ == '__main__':
    # We want to call _enable_attach inside an import to make sure that it works properly that way.
    import _debugger_case_wait_for_attach_impl
