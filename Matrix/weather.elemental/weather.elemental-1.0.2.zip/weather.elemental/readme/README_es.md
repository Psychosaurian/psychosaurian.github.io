# Elemental Weather (weather.elemental)

Complemento del proveedor meteorológico Kodi para The Weather Channel con cobertura mundial actual, diaria (3, 5, 7, 10 o 15 días), cada hora (2, 3, 10 o 15 horas), 36 horas (esta mañana, esta noche). , mañana por la mañana o esta noche, mañana por la mañana, mañana por la noche) y previsiones de fin de semana. También puede proporcionar mapas meteorológicos de The Weather Channel y/o OpenWeatherMap. También se encuentran disponibles alertas y advertencias meteorológicas.

## ¿Por qué utilizar Elemental Weather?

Desde el lanzamiento de Kodi Matrix, que ya no funcionaría con proveedores meteorológicos más antiguos de Kodi Leia y anteriores, no ha habido complementos de proveedores meteorológicos con buena cobertura mundial. La mayoría de los usuarios se han decidido por Multi Weather, que combina pronósticos de Yahoo, Weatherbit y OpenWeatherMap, pero la cobertura de pronóstico de áreas con menor población sigue siendo deficiente a pesar de las múltiples fuentes. Si bien las máscaras de Kodi a menudo admiten períodos de pronóstico adicionales más allá de las horas y los días, ninguno de los proveedores de clima disponibles en los repositorios oficiales de Kodi devuelve todos los tipos de pronóstico que son capaces de mostrar. Además, aunque Multi Weather puede recuperar mapas meteorológicos de OpenWeatherMap, ninguno de ellos ofrece mapas de The Weather Channel, que incluyen mapas satelitales y de RADAR, ninguno de los cuales está disponible en OpenWeatherMap.

Si desea la cobertura mundial, el rango de períodos de pronóstico y los mapas disponibles en The Weather Channel, entonces desea Elemental Weather.

## Requisitos

Este complemento requiere Kodi 19.0 (Matrix) o posterior. Los mapas meteorológicos de Weather Channel están integrados, pero si también desea mapas de OpenWeatherMap, deberá registrarse para obtener una clave API de OpenWeatherMap gratuita (detalles a continuación).

## Soporte para la piel

Muchas máscaras de Kodi populares tratan el clima como una ocurrencia de último momento. Aunque la mayoría lo hace, algunos no muestran el tiempo en absoluto, y aquellos que sí lo hacen a menudo sólo muestran las condiciones actuales y los pronósticos diarios y horarios. Elemental Weather ha sido diseñado para proporcionar todos los atributos de pronóstico extendido proporcionados por todos los proveedores de clima disponibles en los repositorios oficiales de Kodi, lo que significa que debería funcionar con cualquier máscara popular, independientemente de para qué proveedor de clima se optimizó esa máscara.

Como se mencionó anteriormente, Elemental Weather proporciona una gama completa de períodos y tipos de pronóstico, pero dependiendo del aspecto de Kodi que esté utilizando, es posible que algunos o todos esos pronósticos no estén disponibles para usted. Además, aunque Elemental Weather puede proporcionar pronósticos diarios con hasta 15 días de anticipación y pronósticos por hora con hasta 15 horas, es posible que su máscara Kodi no muestre todas esas horas y días. Por ejemplo, es común que las máscaras solo muestren pronósticos de siete o diez días, incluso si el complemento del proveedor devuelve más que eso.

Elemental Weather devolverá alertas meteorológicas en dos formatos diferentes, pero es posible que su máscara Kodi no utilice ninguno de ellos, por lo que incluso si habilita las alertas meteorológicas en la configuración de Elemental Weather es posible que no las vea.

Si habilita todos los tipos de mapas meteorológicos disponibles en The Weather Channel y OpenWeatherMap, Elemental Weather puede proporcionar hasta 13 mapas, pero ninguna de las máscaras populares probadas mostraría más de cinco de ellos. Esto puede cambiar si este complemento gana popularidad, pero por ahora sus únicas opciones si desea una mejor compatibilidad con los mapas es pedirle a su desarrollador de máscaras favorito que actualice sus máscaras, aprenda cómo modificar la máscara usted mismo o busque máscaras capaces de mostrar más de sólo cinco mapas.

## Configuración

Element Weather es altamente configurable y permite hasta diez ubicaciones de pronóstico. Si su máscara no admite todas sus funciones, puede desactivarlas individualmente o reducir la cantidad de horas o días recuperados para reducir el tráfico de Internet innecesario. La configuración se divide en cuatro pestañas...

### Ubicaciones

Aquí puede ingresar hasta diez ubicaciones para recuperar pronósticos. Haga clic en cualquier línea de ubicación e ingrese una cadena de búsqueda. Si ingresa una cadena de búsqueda vacía, se le preguntará si desea eliminar la ubicación que ya se encuentra en ese espacio.

Cuando elige la ubicación que desea entre los resultados de la búsqueda, tiene la oportunidad de editar el nombre de la ubicación. Una vez que haya aceptado el nombre de una ubicación, la única forma de cambiarlo es buscar esa ubicación nuevamente.

### General

#### Resultados de búsqueda detallados

Si está habilitado, los resultados de la búsqueda de ubicación en la pestaña anterior incluirán la latitud/longitud y el tipo de ubicación (es decir, ciudad/pueblo/pueblo, punto de interés, vecindario, etc.). Si está deshabilitado, solo se muestra el nombre de la ubicación en los resultados de búsqueda. El valor predeterminado está habilitado.

#### Mostrar ventanas emergentes de error

Los proveedores del tiempo se ejecutan en segundo plano y normalmente no interactúan con el usuario excepto a través de la visualización del tiempo. Si esta opción está habilitada, una ventana emergente mostrará errores en la pantalla y los guardará en el archivo de registro de Kodi. Si está deshabilitado, los errores solo se guardan en el archivo de registro. El valor predeterminado está deshabilitado.

#### Precipitación de hoy

Esto le permite establecer el período de tiempo utilizado para la acumulación de precipitación. Las opciones son la última hora, las últimas 6 horas o las últimas 24 horas. El valor predeterminado es 24 horas.

#### La nieve de hoy

Lo mismo que para la precipitación de hoy, pero para acumulaciones de nieve.

### Previsiones

#### A diario

Seleccione el número de días proporcionados por el pronóstico diario. Las opciones son 3, 5, 7, 10 o 15 días. El valor predeterminado es 7 días.

#### A diario - Texto detallado de Outlook

Si está habilitado, cada día incluirá un pronóstico detallado de las perspectivas. Dependiendo de la máscara que esté utilizando, esto puede saturar demasiado la pantalla. Si está desactivado, el pronóstico previsto será solo unas pocas palabras, como "Soleado" o "Mayormente nublado". El valor predeterminado está deshabilitado.

#### Cada hora

Seleccione el número de horas que proporciona la previsión horaria. Las opciones son 2, 3, 10 o 15 días. El valor predeterminado es 10 horas.

#### Cada hora - Texto detallado de Outlook

Igual que para la previsión Diaria, pero para la previsión Horaria. El valor predeterminado está deshabilitado.

#### 36 horas

Activa o desactiva la previsión de 36 horas. El valor predeterminado está habilitado.

#### 36 horas - Texto detallado de Outlook

Igual que para la previsión Diaria, pero para la previsión de 36 Horas. El valor predeterminado está deshabilitado.

#### Fin de semana

Activa o desactiva la previsión del fin de semana. El valor predeterminado está habilitado.

#### Fin de semana - Texto detallado de Outlook

Igual que para la previsión Diaria, pero para la previsión de Fin de Semana. El valor predeterminado está deshabilitado.

#### Alertas

Activa o desactiva las alertas meteorológicas.

#### Mostrar notificación de alerta en el nombre de la ubicación

Si está habilitado, el nombre de la ubicación tendrá "¡Alerta meteorológica!" o "¡Alertas meteorológicas!" se adjunta al nombre de la ubicación para que la existencia de alertas sea visible en la pantalla de inicio. El valor predeterminado está habilitado.

#### Color de notificación de alerta

Le permite cambiar el color del texto "¡Alerta meteorológica!" adjunto al nombre de la ubicación en caso de que sea difícil verlo en la máscara que está utilizando. El valor predeterminado es <span style="color:#daa520">Vara de oro</span >.

### Mapas

Esta sección le permite seleccionar qué mapas meteorológicos se recuperarán y cómo se mostrarán.

#### Nivel de zoom del mapa

Nivel de zoom para mapas meteorológicos. El rango es 3-10. El valor predeterminado es 7.

#### The Weather Channel - Incluir mapas

Activa o desactiva la recuperación de mapas meteorológicos de The Weather Channel. El valor predeterminado está deshabilitado.

#### The Weather Channel - Obtener &lt;tipo de mapa&gt; Mapa

Habilita o deshabilita el tipo de mapa meteorológico especificado.

#### OpenWeatherMap - Incluir mapas

Habilita o deshabilita la recuperación de mapas meteorológicos de OpenWeatherMap. El valor predeterminado está deshabilitado.

#### OpenWeatherMap - Clave API

Si desea recuperar mapas de OpenWeatherMap, debe [registrarse para obtener una clave API gratuita](https://openweathermap.org/appid). Una vez que haya creado una cuenta, ingrese [su clave](https://home.openweathermap.org/api_keys) aquí.

#### OpenWeatherMap - Obtener &lt;tipo de mapa&gt; Mapa

Habilita o deshabilita el tipo de mapa meteorológico especificado.

## Información para desolladores

Todos los valores devueltos por el complemento incluirán sus unidades.
Skinners no tendrá que preocuparse por eso.

NOTA: Las condiciones actuales siempre utilizarán unidades métricas porque Kodi las convertirá, pero las unidades de pronóstico diarias y horarias coincidirán con la configuración regional de Kodi.

```
-----------------------------------------
ETIQUETAS METEOROLÓGICAS KODI POR DEFECTO
-----------------------------------------

CURRENT
-------
Current.Location
Current.Condition
Current.Temperature
Current.Wind
Current.WindDirection
Current.Humidity
Current.FeelsLike
Current.DewPoint
Current.UVIndex
Current.ConditionIcon      (p.ej. '28.png')
Current.FanartCode         (p.ej. '28')

DAY [0-6]
---------
Day%i.Title
Day%i.HighTemp
Day%i.LowTemp
Day%i.Outlook
Day%i.OutlookIcon
Day%i.FanartCode

ALERTS
------
Alerts

WEATHERPROVIDER
----------------
WeatherProvider
WeatherProviderLogo

-----------------------------------
ETIQUETAS METEOROLÓGICAS EXTENDIDAS
-----------------------------------

FORECAST
--------
Forecast.IsFetched
Forecast.City
Forecast.Country
Forecast.Latitude
Forecast.Longitude
Forecast.Updated           (fecha y hora en que Weather Channel recuperó el pronóstico)


CURRENT
-------
Current.IsFetched
Current.OutlookIcon        (p.ej. '28.png' - duplicado de Current.ConditionIcon)
Current.Visibility         (distancia visible)
Current.Pressure           (presión del aire)
Current.PressureChange
Current.SeaLevel           (presión al nivel del mar)
Current.Precipitation      (acumulación en la última hora)
Current.Snow               (acumulación en la última hora)
Current.Cloudiness         (cobertura de nubes)
Current.WindGust           (Es posible que no se suministre para todas las ubicaciones.)

TODAY
-----
Today.IsFetched
Today.Sunrise
Today.Sunset

HOURLY [1-24]
-------------
Hourly.IsFetched
Hourly.%i.Time             (p.ej. '12:00')
Hourly.%i.LongDate         (largo día de la semana. es decir, "lunes")
Hourly.%i.ShortDate        (día corto de la semana. es decir, "lun")
Hourly.%i.Outlook          (p.ej. 'Lluvias muy intensas')
Hourly.%i.OutlookIcon      (p.ej. '28.png')
Hourly.%i.FanartCode       (p.ej. '28')
Hourly.%i.Temperature
Hourly.%i.FeelsLike
Hourly.%i.Humidity
Hourly.%i.Precipitation    (probabilidad de precipitación)
Hourly.%i.RainDepth        (Cantidad de lluvia prevista para esta hora.)
Hourly.%i.SnowDepth        (Profundidad de nieve prevista para esta hora.)
Hourly.%i.WindSpeed
Hourly.%i.WindDirection    (p.ej. 'SSW')
Hourly.%i.WindDegree       (p.ej. '220°')
Hourly.%i.DewPoint         (no suministrado por Weather Network, calculado utilizando la fórmula de Magnus-Tetens)

DAILY [1-15]
------------
Daily.IsFetched
Daily.%i.Title             (nombre del día sin formato de la API de Weather Channel)
Daily.%i.LongDay           (p.ej. 'Lunes': puede ser 'Hoy', 'Esta noche' o 'Mañana')
Daily.%i.ShortDay          (p.ej. 'Lun': puede ser 'Hoy', 'Esta noche' o 'Mañana')
Daily.%i.LongDate          (día del mes: solo se proporciona si LongDay no es "Hoy", "Esta noche" o "Mañana")
Daily.%i.ShortDate         (día del mes: solo se proporciona si LongDay no es "Hoy", "Esta noche" o "Mañana")
Daily.%i.Outlook           (p.ej. 'Mayormente nublado')
Daily.%i.OutlookIcon       (p.ej. '28.png')
Daily.%i.FanartCode        (p.ej. '28')
Daily.%i.Humidity
Daily.%i.Precipitation     (probabilidad de precipitación)
Daily.%i.HighTemperature   (temperatura más alta que se alcanzará hoy; no se proporciona si LongDay es 'Esta noche')
Daily.%i.LowTemperature    (temperatura más baja que se alcanzará hoy)
Daily.%i.Narrative         (p.ej. 'Mezcla de sol y nubes. Máximas de 1 a 3 °C y mínimas de -5 a -3 °C.')
Daily.%i.WindSpeed
Daily.%i.WindDirection     (p.ej. 'SSW')
Daily.%i.WindDegree        (p.ej. '220°')
Daily.%i.Cloudiness        (% cobertura)
Daily.%i.UVIndex           (p.ej. '1 (Bajo)')
Daily.%i.Sunrise
Daily.%i.Sunset
Daily.%i.MoonPhase         (p.ej. 'Luna creciente')
Daily.%1.MoonPhaseCode     (p.ej. 'WXC')
Daily.%i.Moonrise
Daily.%i.Moonset
Daily.%i.RainDepth         (cantidad de lluvia para el día)
Daily.%i.SnowDepth         (Profundidad de nieve en el suelo durante el día.)

36-HOUR [1-3]
-------------
36Hour.IsFetched
36Hour.%i.Heading
36Hour.%i.FanartCode
36Hour.%i.TemperatureHeading
36Hour.%i.Temperature
36Hour.%i.FeelsLike
36Hour.%i.Outlook
36Hour.%i.Precipitation
36Hour.%i.Cloudiness

WEEKEND [1-2]
-------------
Weekend.IsFetched
Weekend.%i.LongOutlookDay
Weekend.%i.ShortDay
Weekend.%i.LongDate
Weekend.%i.ShortDate
Weekend.%i.Outlook
Weekend.%i.LongOutlookDay
Weekend.%i.LongOutlookNight
Weekend.%i.OutlookIcon
Weekend.%i.FanartCode
Weekend.%i.HighTemperature
Weekend.%i.LowTemperature
Weekend.%i.WindSpeed
Weekend.%i.WindDirection
Weekend.%i.Rain
Weekend.%i.Precipitation
Weekend.%i.Snow
Weekend.%i.ChancePrecipitation
Weekend.%i.Humidity
Weekend.%i.Cloudiness

ALERTS [1-10]
-------------
Alerts.IsFetched
Alerts.%i.Status           (Lo mismo que Severity)
Alerts.%i.MessageType
Alerts.%i.Category
Alerts.%i.Severity
Alerts.%i.Certainty
Alerts.%i.Urgency
Alerts.%i.Headline
Alerts.%i.Response
Alerts.%i.Significance
Alerts.%i.StartDate
Alerts.%i.EndDate
Alerts.%i.Description
Alerts.%i.Message          (Lo mismo que Description)
Alerts.%i.Instruction

MAP [1-5]
---------
Map.IsFetched
Map.%i.Area
Map.%i.Layer
Map.%i.Heading
Map.%i.Legend
```