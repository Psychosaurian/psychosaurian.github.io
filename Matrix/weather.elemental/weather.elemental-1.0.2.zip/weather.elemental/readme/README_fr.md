# Elemental Weather (weather.elemental)

Module complémentaire de fournisseur météo Kodi pour The Weather Channel avec une couverture mondiale du courant actuel, quotidien (3, 5, 7, 10 ou 15 jours), horaire (2, 3, 10 ou 15 heures), 36 heures (ce matin, ce soir , demain matin ou ce soir, demain matin, demain soir) et les prévisions du fin de semaine. Il peut également fournir des cartes météorologiques The Weather Channel et/ou OpenWeatherMap. Des alertes et avertissements météorologiques sont également disponibles.

## Pourquoi utiliser Elemental Weather ?

Depuis la sortie de Kodi Matrix, qui ne fonctionnerait plus avec les anciens fournisseurs météo de Kodi Leia et antérieurs, il n'y a eu aucun module complémentaire de fournisseur météo offrant une bonne couverture mondiale. La plupart des utilisateurs ont opté pour Multi Weather qui combine les prévisions de Yahoo, Weatherbit et OpenWeatherMap, mais la couverture des prévisions des zones à faible population est encore faible malgré les multiples sources. Alors que les skins Kodi prennent souvent en charge des périodes de prévision supplémentaires au-delà de l'heure et du jour, aucun des fournisseurs météorologiques disponibles dans les référentiels officiels Kodi ne renvoie tous les types de prévisions qu'ils sont capables d'afficher. De plus, bien que Multi Weather puisse récupérer des cartes météorologiques d'OpenWeatherMap, aucun d'entre eux ne propose de cartes de The Weather Channel, qui incluent des cartes satellite et RADAR, dont aucune n'est disponible sur OpenWeatherMap.

Si vous souhaitez bénéficier de la couverture mondiale, de la plage de périodes de prévision et des cartes disponibles sur The Weather Channel, vous souhaitez Elemental Weather.

## Exigences

Cet addon nécessite Kodi 19.0 (Matrix) ou version ultérieure. Les cartes météorologiques de Weather Channel sont intégrées, mais si vous souhaitez également des cartes OpenWeatherMap, vous devrez vous inscrire pour obtenir une clé API OpenWeatherMap gratuite (détails ci-dessous).

## Soutien de la peau

De nombreux skins Kodi populaires traitent la météo après coup. Bien que la plupart le fassent, certains n'affichent pas du tout la météo, et ceux qui le font affichent souvent uniquement les conditions actuelles et les prévisions quotidiennes et horaires. Elemental Weather a été conçu pour fournir tous les attributs de prévision étendus fournis par tous les fournisseurs météorologiques disponibles dans les référentiels officiels Kodi, ce qui signifie qu'il devrait fonctionner avec n'importe quel skin populaire, quel que soit le fournisseur météo pour lequel ce skin a été optimisé.

Comme mentionné précédemment, Elemental Weather propose une gamme complète de périodes et de types de prévisions, mais selon le skin Kodi que vous utilisez, certaines ou la totalité de ces prévisions peuvent ne pas être disponibles. De plus, bien qu'Elemental Weather puisse fournir des prévisions quotidiennes jusqu'à 15 jours à l'avance et des prévisions horaires jusqu'à 15 heures, votre skin Kodi peut ne pas afficher toutes ces heures et tous ces jours. Par exemple, il est courant que les skins n'affichent que des prévisions sur sept ou dix jours, même si le module complémentaire du fournisseur renvoie plus que cela.

Elemental Weather renverra des alertes météo dans deux formats différents, mais votre skin Kodi pourrait ne les utiliser ni l'un ni l'autre. Ainsi, même si vous activez les alertes météo dans les paramètres Elemental Weather, vous ne les verrez peut-être pas.

Si vous activez tous les types de cartes météorologiques disponibles sur The Weather Channel et OpenWeatherMap, Elemental Weather peut fournir jusqu'à 13 cartes, mais aucun des skins populaires testés n'en affichera plus de cinq. Cela peut changer si cet addon gagne en popularité, mais pour l'instant, votre seul choix si vous souhaitez une meilleure prise en charge des cartes est de demander à votre développeur de skin préféré de mettre à jour ses skins, d'apprendre à modifier le skin vous-même ou de rechercher des skins capables d'afficher plus de juste cinq cartes.

## Configuration

Element Weather est hautement configurable, permettant jusqu'à dix emplacements de prévisions. Si votre skin ne prend pas en charge toutes ses fonctionnalités, vous pouvez les désactiver individuellement ou réduire le nombre d'heures ou de jours récupérés pour réduire le trafic Internet inutile. Les paramètres sont divisés en quatre onglets...

### Emplacements

Ici, vous pouvez saisir jusqu'à dix emplacements pour lesquels récupérer les prévisions. Cliquez sur n'importe quelle ligne de localisation et entrez une chaîne de recherche. Si vous entrez une chaîne de recherche vide, il vous est demandé si vous souhaitez supprimer l'emplacement déjà présent dans cet emplacement.

Lorsque vous choisissez un emplacement souhaité dans les résultats de recherche, vous avez la possibilité de modifier le nom de l'emplacement. Une fois que vous avez accepté un nom de lieu, la seule façon de le modifier est de rechercher à nouveau ce lieu.

### Général

#### Résultats de recherche détaillés

Si cette option est activée, les résultats de la recherche d'emplacement sur l'onglet précédent incluront la latitude/longitude et le type d'emplacement (c'est-à-dire ville/village, point d'intérêt, quartier, etc.). S'il est désactivé, seul le nom de l'emplacement est affiché dans les résultats de recherche. La valeur par défaut est activée.

#### Afficher les fenêtres contextuelles d'erreur

Les fournisseurs de météo fonctionnent en arrière-plan et n'interagissent normalement pas avec l'utilisateur sauf via l'affichage météo. Si cette option est activée, une fenêtre contextuelle affichera les erreurs à l'écran et les enregistrera dans le fichier journal Kodi. Si cette option est désactivée, les erreurs sont uniquement enregistrées dans le fichier journal. La valeur par défaut est désactivée.

#### Les précipitations d'aujourd'hui

Cela vous permet de définir la période de temps utilisée pour l’accumulation des précipitations. Les choix sont la dernière heure, les 6 dernières heures ou les dernières 24 heures. La valeur par défaut est 24 heures.

#### La neige d'aujourd'hui

Identique aux précipitations d'aujourd'hui, mais pour les accumulations de neige.

### Prévisions

#### Tous les jours

Sélectionnez le nombre de jours fournis par les prévisions quotidiennes. Les choix sont de 3, 5, 7, 10 ou 15 jours. La valeur par défaut est de 7 jours.

#### Tous les jours - Texte Perspective détaillé

Si cette option est activée, chaque jour comprendra des prévisions détaillées. Selon le skin que vous utilisez, cela peut trop encombrer l'écran. Si cette option est désactivée, les prévisions ne seront que quelques mots, tels que « Ensoleillé » ou « Plutôt nuageux ». La valeur par défaut est désactivée.

#### Horaire

Sélectionnez le nombre d'heures fournies par la prévision horaire. Les choix sont de 2, 3, 10 ou 15 jours. La valeur par défaut est 10 heures.

#### Horaire - Texte Perspective détaillé

Identique à la prévision journalière, mais pour la prévision horaire. La valeur par défaut est désactivée.

#### 36 heures

Activez ou désactivez la prévision sur 36 heures. La valeur par défaut est activée.

#### 36 heures - Texte Perspective détaillé

Identique à la prévision quotidienne, mais pour la prévision sur 36 heures. La valeur par défaut est désactivée.

#### Fin de semaine

Activez ou désactivez les prévisions du fin de semaine. La valeur par défaut est activée.

#### Fin de semaine - Texte Perspective détaillé

Identique à la prévision quotidienne, mais pour la prévision du fin de semaine. La valeur par défaut est désactivée.

#### Alertes

Activez ou désactivez les alertes météo.

#### Afficher la notification d'alerte sur le nom de l'emplacement

Si cette option est activée, le nom de l'emplacement affichera « Alerte météo ! » ou "Alertes météo !" ajouté au nom de l'emplacement afin que l'existence d'alertes soit visible sur l'écran d'accueil. La valeur par défaut est activée.

#### Couleur des notifications d'alerte

Vous permet de changer la couleur du texte « Alerte météo ! » ajouté au nom de l'emplacement au cas où il serait difficile à voir sur le skin que vous utilisez. La valeur par défaut est <span style="color:#daa520">verge d'or</span>.

### Cartes

Cette section vous permet de sélectionner quelles cartes météo seront récupérées et comment elles seront affichées.

#### Niveau de zoom de la carte

Niveau de zoom pour les cartes météo. La plage est de 3 à 10. La valeur par défaut est 7.

#### The Weather Channel - Inclure des cartes

Active ou désactive la récupération des cartes météo de The Weather Channel. La valeur par défaut est désactivée.

#### The Weather Channel - "Obtenir la carte des &lt;type de carte&gt;

Active ou désactive le type de carte météo spécifié.

#### OpenWeatherMap - Inclure des cartes

Active ou désactive la récupération des cartes météorologiques depuis OpenWeatherMap. La valeur par défaut est désactivée.

#### OpenWeatherMap - clé API

Si vous souhaitez récupérer des cartes depuis OpenWeatherMap, vous devez [vous inscrire pour une clé API gratuite](https://openweathermap.org/appid). Une fois que vous avez créé un compte, entrez [votre clé](https://home.openweathermap.org/api_keys) ici.

#### OpenWeatherMap - Obtenir la carte des &lt;type de carte&gt;

Active ou désactive le type de carte météo spécifié.

## Informations pour les écorcheurs

Toutes les valeurs renvoyées par le module complémentaire incluront
leurs unités. Les skinners n’auront pas à s’en soucier.

REMARQUE: les conditions actuelles utiliseront toujours des unités métriques car Kodi les convertira, mais les unités de prévision quotidiennes et horaires correspondront aux paramètres régionaux de Kodi.

```
--------------------------------
ÉTIQUETTES MÉTÉO KODI PAR DÉFAUT
--------------------------------

CURRENT
-------
Current.Location
Current.Condition
Current.Temperature
Current.Wind
Current.WindDirection
Current.Humidity
Current.FeelsLike
Current.DewPoint
Current.UVIndex
Current.ConditionIcon      (par exemple. '28.png')
Current.FanartCode         (par exemple. '28')

DAY [0-6]
---------
Day%i.Title
Day%i.HighTemp
Day%i.LowTemp
Day%i.Outlook
Day%i.OutlookIcon
Day%i.FanartCode

ALERTS
------
Alerts

WEATHERPROVIDER
----------------
WeatherProvider
WeatherProviderLogo

-------------------------
ÉTIQUETTES MÉTÉO ÉTENDUES
-------------------------

FORECAST
--------
Forecast.IsFetched
Forecast.City
Forecast.Country
Forecast.Latitude
Forecast.Longitude
Forecast.Updated           (date et heure auxquelles les prévisions ont été récupérées par Weather Channel)


CURRENT
-------
Current.IsFetched
Current.OutlookIcon        (par exemple. '28.png' - duplicata de Current.ConditionIcon)
Current.Visibility         (distance visible)
Current.Pressure           (pression de l'air)
Current.PressureChange
Current.SeaLevel           (pression au niveau de la mer)
Current.Precipitation      (accumulation sur la dernière heure)
Current.Snow               (accumulation sur la dernière heure)
Current.Cloudiness         (couverture nuageuse)
Current.WindGust           (peut ne pas être fourni pour chaque emplacement)

TODAY
-----
Today.IsFetched
Today.Sunrise
Today.Sunset

HOURLY [1-24]
-------------
Hourly.IsFetched
Hourly.%i.Time             (par exemple. '12:00')
Hourly.%i.LongDate         (longue journée de la semaine. c'est-à-dire "lundi")
Hourly.%i.ShortDate        (longue journée de la semaine. c'est-à-dire "lun")
Hourly.%i.Outlook          (par exemple. "Très fortes pluies")
Hourly.%i.OutlookIcon      (par exemple. '28.png')
Hourly.%i.FanartCode       (par exemple. '28')
Hourly.%i.Temperature
Hourly.%i.FeelsLike
Hourly.%i.Humidity
Hourly.%i.Precipitation    (probabilité de précipitation)
Hourly.%i.RainDepth        (amount of rain predicted for this hour)
Hourly.%i.SnowDepth        (quantité de pluie prévue pour cette heure)
Hourly.%i.WindSpeed
Hourly.%i.WindDirection    (par exemple. 'SSW')
Hourly.%i.WindDegree       (par exemple. '220°')
Hourly.%i.DewPoint         (non fourni par Weather Network, calculé à l'aide de la formule Magnus-Tetens)

DAILY [1-15]
------------
Daily.IsFetched
Daily.%i.Title             (nom du jour brut de l'API Weather Channel)
Daily.%i.LongDay           (par exemple. "Lundi" - peut être "Aujourd'hui", "Ce soir" ou "Demain")
Daily.%i.ShortDay          (par exemple. « Lun » – peut être « Aujourd'hui », « Ce soir » ou « Demain »)
Daily.%i.LongDate          (jour du mois - fourni uniquement si LongDay n'est pas "Aujourd'hui", "Ce soir" ou "Demain")
Daily.%i.ShortDate         (jour du mois - fourni uniquement si LongDay n'est pas "Aujourd'hui", "Ce soir" ou "Demain")
Daily.%i.Outlook           (par exemple. 'Plutôt nuageux')
Daily.%i.OutlookIcon       (par exemple. '28.png')
Daily.%i.FanartCode        (par exemple. '28')
Daily.%i.Humidity
Daily.%i.Precipitation     (probabilité de précipitation)
Daily.%i.HighTemperature   (température la plus élevée qui sera atteinte aujourd'hui - non fournie si LongDay est 'Ce soir')
Daily.%i.LowTemperature    (température la plus basse qui sera atteinte aujourd'hui)
Daily.%i.Narrative         (par exemple. 'Alternance de soleil et de nuages. Des températures maximales de 1 à 3 °C et des températures minimales de -5 à -3 °C.)
Daily.%i.WindSpeed
Daily.%i.WindDirection     (par exemple. 'SSW')
Daily.%i.WindDegree        (par exemple. '220°')
Daily.%i.Cloudiness        (% couverture)
Daily.%i.UVIndex           (par exemple. '1 (faible)')
Daily.%i.Sunrise
Daily.%i.Sunset
Daily.%i.MoonPhase         (par exemple. « Croissant de cire »)
Daily.%1.MoonPhaseCode     (par exemple. 'WXC')
Daily.%i.Moonrise
Daily.%i.Moonset
Daily.%i.RainDepth         (quantité de précipitations pour la journée)
Daily.%i.SnowDepth         (épaisseur de neige au sol pour la journée)

36-HOUR [1-3]
-------------
36Hour.IsFetched
36Hour.%i.Heading
36Hour.%i.FanartCode
36Hour.%i.TemperatureHeading
36Hour.%i.Temperature
36Hour.%i.FeelsLike
36Hour.%i.Outlook
36Hour.%i.Precipitation
36Hour.%i.Cloudiness

WEEKEND [1-2]
-------------
Weekend.IsFetched
Weekend.%i.LongOutlookDay
Weekend.%i.ShortDay
Weekend.%i.LongDate
Weekend.%i.ShortDate
Weekend.%i.Outlook
Weekend.%i.LongOutlookDay
Weekend.%i.LongOutlookNight
Weekend.%i.OutlookIcon
Weekend.%i.FanartCode
Weekend.%i.HighTemperature
Weekend.%i.LowTemperature
Weekend.%i.WindSpeed
Weekend.%i.WindDirection
Weekend.%i.Rain
Weekend.%i.Precipitation
Weekend.%i.Snow
Weekend.%i.ChancePrecipitation
Weekend.%i.Humidity
Weekend.%i.Cloudiness

ALERTS [1-10]
-------------
Alerts.IsFetched
Alerts.%i.Status           (identique à la Severity)
Alerts.%i.MessageType
Alerts.%i.Category
Alerts.%i.Severity
Alerts.%i.Certainty
Alerts.%i.Urgency
Alerts.%i.Headline
Alerts.%i.Response
Alerts.%i.Significance
Alerts.%i.StartDate
Alerts.%i.EndDate
Alerts.%i.Description
Alerts.%i.Message          (identique à la Description)
Alerts.%i.Instruction

MAP [1-5]
---------
Map.IsFetched
Map.%i.Area
Map.%i.Layer
Map.%i.Heading
Map.%i.Legend
```