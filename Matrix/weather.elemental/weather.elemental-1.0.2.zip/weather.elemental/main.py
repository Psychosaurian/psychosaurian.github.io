import sys
from resources.lib.plugin import Plugin

import debugpy as dbg

try:
    dbg.connect(5678)
except:
    pass

if __name__ == '__main__':

    Plugin(sys.argv).route()
