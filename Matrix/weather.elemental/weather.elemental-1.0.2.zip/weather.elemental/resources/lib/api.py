import requests
import arrow
from xbmc import getRegion
from urllib.parse import urlencode
from math import log
from os import environ

BASE_URL = 'https://api.weather.com/v3/'
PRODUCT_SEARCH = 'location/search?'
PRODUCT_CURRENT = 'wx/observations/current?'
PRODUCT_3DAY = 'wx/forecast/daily/3day?'
PRODUCT_5DAY = 'wx/forecast/daily/5day?'
PRODUCT_7DAY = 'wx/forecast/daily/7day?'
PRODUCT_10DAY = 'wx/forecast/daily/10day?'
PRODUCT_15DAY = 'wx/forecast/daily/15day?'
PRODUCT_HOURLY_2DAY = 'wx/forecast/hourly/2day?'
PRODUCT_HOURLY_3DAY = 'wx/forecast/hourly/3day?'
PRODUCT_HOURLY_10DAY = 'wx/forecast/hourly/10day?'
PRODUCT_HOURLY_15DAY = 'wx/forecast/hourly/15day?'
PRODUCT_ALERT_HEADLINES = 'alerts/headlines?'
PRODUCT_ALERT_DETAIL = 'alerts/detail?'

class ApiException(Exception):

    def __enter__(self):

        return self

    def __init__(self, url, statusCode):

        self.__url = url
        self.__statusCode = statusCode

    def statusCode(self):

        return self.__statusCode
    
    def url(self):

        return self.__url
    
class ApiConnectionException(Exception):

    def __enter__(self):

        return self

    def __init__(self, message):

        self.__message = message

    def message(self):

        return self.__message
    
class Api:

    def __enter__(self):

        return self

    def __init__(self, apiKey, locationID = None):

        self.__locationID = locationID
        self.__apiKey = apiKey
        self.__tempUnits = getRegion('tempunit')
        self.__speedUnits = getRegion('speedunit')

        self.__headers = {
            'Accept-Encoding': 'gzip',
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36"
        }

    def __speedConvert(self, kph):

        if self.__speedUnits == 'mph':
            return '%i mph' % round(kph / 1.60934)
        elif self.__speedUnits == 'm/min':
            return '%i m/min' % round(kph * 1000 / 60)
        elif self.__speedUnits == 'm/s':
            return '%i m/s' % round(kph * 1000 / 3600)
        elif self.__speedUnits == 'ft/h':
            return '%i ft/h' % round(kph * 3280.84)
        elif self.__speedUnits == 'ft/min':
            return '%i ft/min' % round(kph * 3280.84 / 60)
        elif self.__speedUnits == 'ft/s':
            return '%i ft/s' % round(kph * 3280.84 / 3600)
        elif self.__speedUnits == 'kts':
            return '%i kts' % round(kph / 1.852)
        elif self.__speedUnits == 'Beaufort':
            if kph <= 2:
                return '0 Beaufort'
            elif kph <= 5:
                return '1 Beaufort'
            elif kph <= 11:
                return '2 Beaufort'
            elif kph <= 19:
                return '3 Beaufort'
            elif kph <= 28:
                return '4 Beaufort'
            elif kph <= 38:
                return '5 Beaufort'
            elif kph <= 49:
                return '6 Beaufort'
            elif kph <= 61:
                return '7 Beaufort'
            elif kph <= 74:
                return '8 Beaufort'
            elif kph <= 88:
                return '9 Beaufort'
            elif kph <= 102:
                return '10 Beaufort'
            elif kph <= 117:
                return '11 Beaufort'
            else:
                return '12 Beaufort'
        elif self.__speedUnits == 'inch/s':
            return '%i inch/s' % round(kph * 39370.1 / 3600)
        elif self.__speedUnits == 'yard/s':
            return '%i yard/s' % round(kph * 1093.61 / 3600)
        elif self.__speedUnits == 'Furlong/Fortnight':
            return '%i Furlong/Fortnight' % round(kph * 1670.24256)
        else:
            return '%i km/h' % kph
        
    def __tempConvert(self, celsius):

        if not celsius:
            return ''
        elif self.__tempUnits == '°F':
            return '%i°F' % round(celsius * 9 / 5 + 32)
        elif self.__tempUnits == 'K':
            return '%iK' % round(celsius + 273.15)
        elif self.__tempUnits == '°Ré':
            return '%i°Ré' % round(celsius * 4 / 5)
        elif self.__tempUnits == '°Ré':
            return '%i°Ré' % round(celsius * 4 / 5)
        elif self.__tempUnits == '°Ra':
            return '%i°Ra' % round(celsius * 9 / 5 + 491.67)
        elif self.__tempUnits == '°Rø':
            return '%i°Rø' % round(celsius * 22 / 40 + 7.5)
        elif self.__tempUnits == '°De':
            return '%i°De' % round((100 - celsius) * 3 / 2)
        elif self.__tempUnits == '°N':
            return '%i°N' % round(celsius * 33 / 100)
        else:
            return '%i°C' % celsius
        
    def __getForecast(self, product, units, language):

        arguments = urlencode({
            'placeid': self.__locationID,
            'language': language,
            'format': 'json',
            'apiKey': self.__apiKey,
            'units': units
        })

        url = BASE_URL + product + arguments

        try:
            result = requests.get(url, headers = self.__headers)

            if result.status_code == 200:
                return result.json()
            else:
                raise ApiException(url, result.status_code)
            
        except requests.exceptions.ConnectionError as e:

            raise ApiConnectionException(e.args[0].args[0])

    def todayForecast(self, language):

        forecast = self.__getForecast(PRODUCT_CURRENT, 'm', language)

        # ---the API doesn't always supply medium and short weather conditions
        conditionsLong =  forecast['wxPhraseLong']
        conditionsMedium = forecast['wxPhraseMedium'] if forecast['wxPhraseMedium'] else conditionsLong
        conditionsShort = forecast['wxPhraseMedium'] if forecast['wxPhraseMedium'] else conditionsMedium if conditionsMedium else conditionsLong
        
        return {

            'iconCode': str(forecast['iconCode']),
            'currentTemp': forecast['temperature'],
            'feelsLike': forecast['temperatureFeelsLike'],
            'conditionsLong': conditionsLong,
            'conditionsMedium': conditionsMedium,
            'conditionsShort': conditionsShort,
            'dewPoint': forecast['temperatureDewPoint'],
            'windSpeed': forecast['windSpeed'],
            'windGust': forecast['windGust'],
            'windDirection': forecast['windDirectionCardinal'],
            'humidity': forecast['relativeHumidity'],
            'uvIndex': forecast['uvIndex'],
            'uvDescription': forecast['uvDescription'],
            'sunRise': arrow.get(forecast['sunriseTimeLocal']),
            'sunSet': arrow.get(forecast['sunsetTimeLocal']),
            'visibility': forecast['visibility'],
            'pressure': forecast['pressureAltimeter'],
            'pressureChange': forecast['pressureChange'],
            'seaLevel': forecast['pressureMeanSeaLevel'],
            'precipitation1hr': forecast['precip1Hour'],
            'precipitation6hr': forecast['precip6Hour'],
            'precipitation24hr': forecast['precip24Hour'],
            'snow': forecast['snow1Hour'],
            'cloudCover': forecast['cloudCoverPhrase'],
            'updated': arrow.get(forecast['validTimeLocal']),
        }

    def dailyForecast(self, language, numDays):
        
        if numDays == 3:
            product = PRODUCT_3DAY
        elif numDays == 5:
            product = PRODUCT_5DAY
        elif numDays == 7:
            product = PRODUCT_7DAY
        elif numDays == 10:
            product = PRODUCT_10DAY
        else:
            product = PRODUCT_15DAY

        result = self.__getForecast(product, 'm', language)

        dayParts = result['daypart'][0]
        dayRange = range(len(result['validTimeLocal']))

        forecast = []

        for dayNum in dayRange:

            partNum = dayNum * 2

            dayName = dayParts['daypartName'][partNum]

            if not dayName:
                partNum += 1
                dayName = dayParts['daypartName'][partNum]

            try:
                moonRise = arrow.get(result['moonriseTimeLocal'][dayNum])
            except:
                moonRise = None

            try:
                moonSet = arrow.get(result['moonsetTimeLocal'][dayNum])
            except:
                moonSet = None

            highTemp = result['temperatureMax'][dayNum]

            forecast.append(

                {
                    'when': arrow.get(result['validTimeLocal'][dayNum]),
                    'dayName': dayName,
                    'iconCode': str(dayParts['iconCode'][partNum]),
                    'highTemp': self.__tempConvert(highTemp) if highTemp else None,
                    'lowTemp': self.__tempConvert(result['temperatureMin'][dayNum]),
                    'feelsLike': self.__tempConvert(dayParts['temperatureHeatIndex'][partNum]),
                    'narrative': result['narrative'][dayNum],
                    'conditionsDay': dayParts['wxPhraseLong'][partNum],
                    'conditionsNight': dayParts['wxPhraseLong'][partNum +1],
                    'precipitation': str(result['qpf'][dayNum]),
                    'precipChance': str(dayParts['precipChance'][partNum]),
                    'windDirection': dayParts['windDirectionCardinal'][partNum],
                    'windDegree': str(dayParts['windDirection'][partNum]),
                    'windSpeed': self.__speedConvert(dayParts['windSpeed'][partNum]),
                    'uvIndex': str(dayParts['uvIndex'][partNum]),
                    'humidity': str(dayParts['relativeHumidity'][partNum]),
                    'cloudiness': str(dayParts['cloudCover'][partNum]),                
                    'uvIndex': dayParts['uvIndex'][partNum],                
                    'uvDescription': dayParts['uvDescription'][partNum],                
                    'sunRise': arrow.get(result['sunriseTimeLocal'][dayNum]),
                    'sunSet': arrow.get(result['sunsetTimeLocal'][dayNum]),
                    'moonRise': moonRise,
                    'moonSet': moonSet,
                    'moonPhase': result['moonPhase'][dayNum],
                    'moonPhaseCode': result['moonPhaseCode'][dayNum],
                    'rainDepth': result['qpf'][dayNum],
                    'snowDepth': result['qpfSnow'][dayNum],
                 }
            )

        return forecast
    
    def hourlyForecast(self, language, numHours):

        if numHours == 2:
            product = PRODUCT_HOURLY_2DAY
        elif numHours == 3:
            product = PRODUCT_HOURLY_3DAY
        elif numHours == 10:
            product = PRODUCT_HOURLY_10DAY
        else:
            product = PRODUCT_HOURLY_15DAY

        result = self.__getForecast(product, 'm', language)

        forecast = []

        hours = range(len(result['temperature']))

        for hour in hours:

            if hour > numHours:
                # ---We have all the hours we are interested in
                break

            temperature = result['temperature'][hour]
            humidity = result['relativeHumidity'][hour]
            forecast.append({
                'iconCode': str(result['iconCode'][hour]),
                'when': arrow.get(result['validTimeLocal'][hour]),
                'temperature': self.__tempConvert(temperature),
                'feelsLike': self.__tempConvert(result['temperatureFeelsLike'][hour]),
                'conditions': result['wxPhraseLong'][hour],
                'precipitation': str(result['precipChance'][hour]),
                'rain': result['qpf'][hour],
                'snow': result['qpfSnow'][hour],
                'windDirection': result['windDirectionCardinal'][hour],
                'windDegree': str(result['windDirection'][hour]),
                'windSpeed': self.__speedConvert(result['windSpeed'][hour]),
                'uvIndex': str(result['uvIndex'][hour]),
                'humidity': humidity,
                'cloudiness': str(result['cloudCover'][hour]),                
                'dewPoint': self.__tempConvert(self.__calculateDewPoint(temperature, humidity))
            })

        return forecast

    def thirtySixHourForecast(self, language):

        result = self.__getForecast(PRODUCT_3DAY, 'm', language)

        dayParts = result['daypart'][0]
        
        if dayParts['daypartName'][0]:
            partRange = range(0,3)
        else:
            partRange = range(1,4)

        forecast = []

        for dayPartNum in partRange:

            dayOrNight = dayParts['dayOrNight'][dayPartNum]

            forecast.append({

                'name': dayParts['daypartName'][dayPartNum],
                'cloudiness': str(dayParts['cloudCover'][dayPartNum]),
                'iconCode': str(dayParts['iconCode'][dayPartNum]),
                'precipitation': dayParts['qpf'][dayPartNum],
                'temperature': self.__tempConvert(dayParts['temperature'][dayPartNum]),
                'feelsLike': self.__tempConvert(dayParts['temperatureHeatIndex' if dayOrNight == 'D' else 'temperatureWindChill'][dayPartNum]),
                'outlook': dayParts['wxPhraseLong'][dayPartNum],
                'narrative': dayParts['narrative'][dayPartNum],
                'dayOrNight': dayOrNight,
            })
        
        return forecast

    def alerts(self, addon, language, latitude, longitude):

        arguments = urlencode({
            'geocode': '%s,%s' % (latitude,longitude),
            'language': language,
            'format': 'json',
            'apiKey': self.__apiKey,
        })

        alerts = []

        while True:

            url = BASE_URL + PRODUCT_ALERT_HEADLINES + arguments

            try:
                result = requests.get(url, headers = self.__headers)

                if result.status_code == 200:

                    json = result.json()
                    for alert in json['alerts']:

                        description = None
                        instruction = None

                        detail = self.__alertDetail(language, alert['detailKey'])
                        if detail:
                            # ---Look for alert text in specified language
                            texts = detail['texts']
                            if len(texts) != 0:
                                description = None
                                for text in texts:
                                    if text['languageCode'].lower() == language.lower():
                                        description = text['description']
                                        instruction = text['instruction']
                                        break
                                
                                if not description and len(texts) > 0:
                                    # ---Couldn't find text for specified language so just use the first one
                                    description = texts[0]['description']
                                    instruction = texts[0]['instruction']
 
                        effectiveTime = alert['effectiveTimeLocal']
                        expireTime = alert['expireTimeLocal']

                        if 'responseTypes' in alert and len(alert['responseTypes']) > 0:
                            responseTypes = alert['responseTypes']
                            responseStr = self.__alertCategory(addon, responseTypes[0]['responseType'])

                            for responseType in responseTypes[2:]:
                                responseStr += ', ' + responseType['responseType']
                        else:
                            responseStr = None

                        if 'categories' in alert and len(alert['categories']) > 0:
                            categories = alert['categories']
                            categoryStr = self.__alertCategory(addon, categories[0]['category'])

                            for category in categories[2:]:
                                categoryStr += ', ' + self.__alertCategory(addon, category['category'])
                        else:
                            categoryStr = None

                        alerts.append({

                            'significance': self.__alertSignificance(addon, alert['significance']),
                            'messageType': alert['messageType'],
                            'eventDescription': alert['eventDescription'],
                            'severity': alert['severity'],
                            'urgency': alert['urgency'],
                            'certainty': alert['certainty'],
                            'areaName': alert['areaName'],
                            'headline': alert['headlineText'],
                            'source': alert['source'],                           
                			'effectiveTime': arrow.get(effectiveTime) if effectiveTime else None,
                            'expireTime': arrow.get(expireTime) if expireTime else None,
                            'disclaimer': alert['disclaimer'],
                            'description': description,
                            'instruction': instruction,
                            'category': categoryStr,
                            'response': responseStr,
                            'displayRank': alert['displayRank'],
                        })


                    if 'metadata' in json and 'next' in json['metadata'] and json['metadata']['next']:

                        # ---There are more alerts to retrieve
                        arguments = urlencode({
                            'geocode': '%s,%s' % (latitude,longitude),
                            'language': language,
                            'format': 'json',
                            'apiKey': self.__apiKey,
                            'next': json['metadata']['next']
                        })

                    else:

                        # ---We are done retrieving alerts
                        break

                elif result.status_code in (204, 404):
                    # ---No  more alerts found
                    if len(alerts) == 0:
                        # ---We didn't find ANY alerts so return None instead of an array
                        alerts = None
                    break
                else:
                    raise ApiException(url, result.status_code)
                
            except requests.exceptions.ConnectionError as e:

                raise ApiConnectionException(e.args[0].args[0])
        
        # ---Sort alerts by recommended ranking
        return sorted(alerts, key=lambda x: x['displayRank']) if alerts else None

    def __alertDetail(self, language, detailKey):

        arguments = urlencode({

            'alertId': detailKey,
            'language': language,
            'format': 'json',
            'apiKey': self.__apiKey
        })

        url = BASE_URL + PRODUCT_ALERT_DETAIL + arguments
        result = requests.get(url, headers = self.__headers)

        if result.status_code == 200:
            try:
                return result.json()['alertDetail']
            except:                
                return None
        else:
            return None

    def __alertSignificance(self, addon, code):

        if code == 'A':
            stringNum = 32451
        elif code == 'B':
            stringNum = 32452
        elif code == 'L':
            stringNum = 32453
        elif code == 'M':
            stringNum = 32454
        elif code == 'O':
            stringNum = 32455
        elif code == 'R':
            stringNum = 32456
        elif code == 'S':
            stringNum = 32457
        elif code == 'W':
            stringNum = 32458
        else: # 'Y'
            stringNum = 32459

        return addon.getLocalizedString(stringNum)

    def __alertCategory(self, addon, category):

        if category == 'Geo':
            stringNum = 32471
        elif category == 'Met':
            stringNum = 32472
        elif category == 'Safety':
            stringNum = 32473
        else: # category == 'Security':
            stringNum = 32474

        return addon.getLocalizedString(stringNum)

    def __calculateDewPoint( self, temperature, humidity):

        # ---Use the Magnus-Tetens formula to calculate dew point
        x = log(humidity/100) + (17.625 * temperature / (temperature + 243.04))
        
        return round(243.04 * x / (17.625 - x))

    @staticmethod
    def decodeKey(encodedKey: str):
        
        decoded = ''
        split = encodedKey.split('-')
        for section in split:            
            decoded += hex(int(section))[2:]   
        
        return decoded
    
    def searchLocation(self,query):

        arguments = urlencode({

            'query': query,
            'language': 'en-CA', 
            'format': 'json', 
            'locationType': 'city,locality,neighborhood,postal,poi',
            'apiKey': self.__apiKey,
            }
        )

        url = BASE_URL + PRODUCT_SEARCH + arguments

        try:

            result = requests.get(url, headers = self.__headers)

            if result.status_code == 404:

                # ---if no matches are found the result status code will be 404
                locations = None
                
            elif result.status_code != 200:

                # ---Something went wrong
                raise ApiException(url, result.status_code)
            else:

                json = result.json()
                
                locationNode = json['location']
                locationRange = range(len(locationNode['address']))

                locations = []
                for location in locationRange:
                    
                    locations.append({

                        'address': locationNode['address'][location], 
                        'locationID': locationNode['placeId'][location],
                        'latitude': locationNode['latitude'][location],
                        'longitude': locationNode['longitude'][location],
                        'city': locationNode['city'][location],
                        'country': locationNode['country'][location],
                        'type': locationNode['type'][location],
                    })

            return locations
        
        except requests.exceptions.ConnectionError as e:

            raise ApiConnectionException(e.args[0].args[0])
