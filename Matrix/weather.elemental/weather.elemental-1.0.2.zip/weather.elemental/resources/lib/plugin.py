from xbmc import Keyboard, log, getLocalizedString, getLanguage, getRegion, \
    executebuiltin, ISO_639_1, ENGLISH_NAME, LOGERROR
from xbmcgui import Window, ListItem, Dialog
from xbmcaddon import Addon
from urllib.parse import urlencode
import json
from os.path import join
from os import environ
import locale
from typing import cast

from resources.lib.api import Api, ApiException, ApiConnectionException

# TODO: Separate zoom level for each location?
# TODO: Add future forecast maps?

MAX_ALERTS = 10

class Plugin:

    def __enter__(self):

        return self

    def __init__(self, argv):

        self.__mode = argv[1]
        self.__window = Window(12600)
        self.__twcApiKey = Api.decodeKey('3790670366-2027570933-2970230392-3667326245')
        self.__languageCode = self.__getLanguageCode()
        self.__arrowLanguageCode = self.__getLanguageCode(forArrow=True)
        self.__addon = Addon()
        self.__timeFormat = self.__addon.getLocalizedString(32103 if getRegion('meridiem') == '/' else 32102)
        self.__dateFormat = self.__convertedDateFormat('dateshort')
        self.__imperialUnits = (-1 == '|km/h|m/min|m/s|'.find('|' + getRegion('speedunit') + '|'))

        # ---Read in the user settings
        self.__showSearchCoordinates = self.__addon.getSettingBool('detailed-search-results')
        self.__showErrorPopups = self.__addon.getSettingBool('show-error-popups')

    def __convertedDateFormat(self, dateLength):

        dateFormat = getRegion(dateLength)

        dateFormat = dateFormat. \
            replace('%A', 'dddd'). \
            replace('%B', 'MMMM'). \
            replace('%d', 'D') . \
            replace('%Y', 'YYYY'). \
            replace('%m', 'MM')
        
        return dateFormat

    def __getLanguageCode(self, forArrow = False):

        language = getLanguage(ISO_639_1, True)

        if len(language) < 5:
        
            # ---Bug in system call, try to figure out the language
            languageEnglish = getLanguage(ENGLISH_NAME)

            if languageEnglish == 'French (Canada)':
                language = 'fr-CA'
            elif languageEnglish == 'Spanish (Mexico)':
                language = 'es-ES' if forArrow else 'es-MX'
            elif languageEnglish == 'Spanish (Argentina)':
                language = 'es-ES' if forArrow else 'es-AN'
            elif languageEnglish == 'Basque':
                # ---'eu' is the 2-digit code for Basque but they don't seem to have a country code 
                language = 'eu-EU'
            elif languageEnglish == 'Chinese (Simple)':
                language = 'zh-CN'
            elif languageEnglish == 'Chinese (Traditional)' and language == '-tw':
                language = 'zh-TW'
            elif languageEnglish == 'English':
                language = 'en-GB'
            elif languageEnglish == 'English (Australia)':
                language = 'en-AU'
            elif languageEnglish == 'English (New Zealand)':
                language = 'en-GB' if forArrow else 'en-NZ'
            elif languageEnglish == 'English (US)':
                language = 'en-US'
            elif languageEnglish == 'Filipino (Talagog)': # [SIC] (it's actually Tagalog)
                language = 'tl-PH'
            elif languageEnglish == 'Hindi (Devanagiri)':
                language = 'hi' + language.upper()
            elif languageEnglish == 'Mongolian (Mongolia)':
                language = 'mn-MN'
            elif languageEnglish == 'Silesian': # This language has no ISO 639-1 code
                language = cast(str, locale.getdefaultlocale()[0]).replace('_', '-')
            else:
                Dialog().ok('Unrecognized ISO 639-1 Code', languageEnglish + ': ' + language)

                # ---Didn't recognize the language, use the default
                language = cast(str, locale.getdefaultlocale()[0]).replace('_', '-')
                
        elif language == 'pb-br':
                # ---pb-br is not the correct locale code for Brazilian PortugUese
                language = 'pt-br' 

        return language

    def route(self):

        if self.__mode.startswith('loc'):

            # ---Settings is asking to configure one of the location slots
            self.__setLocation(self.__mode[3:])

        elif self.__mode.startswith('help-'):

            self.__help(self.__mode[5:])

        else:

            # ---Kodi is asking for weather information for a location, make sure that location # is configured
            detailsStr = self.__addon.getSettingString('loc' + self.__mode + 'details')
            if detailsStr != '':

                # ---Yes, this locaton number is valid, get addon settings first
                dailyDays = self.__addon.getSettingInt('daily-days')
                hourlyHours = self.__addon.getSettingInt('hourly-hours')
                include36Hours = self.__addon.getSettingBool('include-36hour')
                includeWeekend = self.__addon.getSettingBool('include-weekend')
                includeAlerts = self.__addon.getSettingBool('include-alerts')
                includeTwcMaps = self.__addon.getSettingBool('include-twc-maps')
                includeOwmMaps = self.__addon.getSettingBool('include-owm-maps')
                
                locationDetails = json.loads(detailsStr)
                locationID = locationDetails['locationID']

                if locationID != '':

                    try:
                        # ---Current conditions
                        currentConditions = Api(self.__twcApiKey, locationID).todayForecast(self.__languageCode)
                        self.__current(currentConditions, locationDetails)

                        # ---Daily forecast
                        if dailyDays > 0:

                            outlookElement = 'narrative' if self.__addon.getSettingBool('detailed-daily-outlook') else 'conditionsDay'

                            dailyForecast = Api(self.__twcApiKey, locationID).dailyForecast(self.__languageCode, dailyDays)
                            
                            dayNum = 1
                            for day in dailyForecast:

                                self.__daily(dayNum, day, outlookElement)
                                dayNum += 1

                            while dayNum < 17:
                                self.__clearDaily(dayNum)
                                dayNum += 1

                            self.__window.setProperty('Daily.IsFetched', 'true')
                        else:
                            self.__window.clearProperty('Daily.IsFetched')
                            for dayNum in range(1,16):
                                self.__clearDaily(dayNum)

                        # ---Hourly forecasts
                        if hourlyHours > 0:
                            
                            hourlyForecast = Api(self.__twcApiKey, locationID).hourlyForecast(self.__languageCode, hourlyHours)

                            hourNum = 1
                            for hour in hourlyForecast:

                                self.__hourly(hourNum, hour)

                                hourNum += 1

                            while hourNum < 17:
                                self.__clearHourly(hourNum)
                                hourNum += 1

                            self.__window.setProperty('Hourly.IsFetched', 'true')
                        else:
                            self.__window.clearProperty('Hourly.IsFetched')
                            for hourNum in range(1,16):
                                self.__clearHourly(hourNum)

                        # ---36 Hour forecast
                        if include36Hours:

                            outlookElement = 'narrative' if self.__addon.getSettingBool('detailed-36hour-outlook') else 'outlook'
                            forecast = Api(self.__twcApiKey, locationID).thirtySixHourForecast(self.__languageCode)

                            for dayPart in range(1,4):

                                self.__36hour(dayPart, forecast[dayPart -1], outlookElement)

                            self.__window.setProperty('36Hour.IsFetched', 'true')
                        else:
                            for dayPart in range(1,4):
                                self.__clear36hour(dayPart)
                            self.__window.clearProperty('36Hour.IsFetched')

                        # ---Weekend
                        if includeWeekend:

                            outlookElement = 'narrative' if self.__addon.getSettingBool('detailed-weekend-outlook') else 'conditionsDay'

                            # ---Get forecast for next ten days
                            dailyForecast = Api(self.__twcApiKey, locationID).dailyForecast(self.__languageCode, 7)

                            # ---scan for the next Saturday (if it is currently Sunday we will get NEXT weekend)
                            for dayNum in range(0,len(dailyForecast)):

                                forecastDate = dailyForecast[dayNum]['when']

                                if 6 == forecastDate.isoweekday():

                                    # ---This is a Saturday
                                    self.__weekend(1, dailyForecast[dayNum], outlookElement)
                                    self.__weekend(2, dailyForecast[dayNum+1], outlookElement)

                                    # ---We are done, stop looking for a Saturday
                                    break
                                        
                            self.__window.setProperty('Weekend.IsFetched', 'true')

                        else:

                            self.__clearWeekend(1)
                            self.__clearWeekend(2)
                            self.__window.clearProperty('Weekend.IsFetched')

                        # ---Alerts
                        if includeAlerts:

                            alerts = Api(self.__twcApiKey, locationID).alerts(
                                
                                self.__addon,
                                self.__languageCode, 
                                locationDetails['latitude'], 
                                locationDetails['longitude']
                            )

                            # ---Did we get any alerts for this location?
                            if alerts:

                                # ---Process the first alert
                                self.__alert(1, alerts[0])

                                if alerts[0]['description']:
                                    alertsText = alerts[0]['description']
                                else:
                                    alertsText = ''

                                # ---Process any extra alerts
                                alertNum = 2
                                for alert in alerts[2:]:

                                    self.__alert(alertNum, alert)

                                    if alert['description']:
                                        alertsText += '\n==========================================================\n' + alert['description']

                                    alertNum += 1

                                if alertsText != '':
                                    self.__window.setProperty('Alerts', alertsText)

                                alertCount = alertNum -1
                                self.__window.setProperty('Alerts.Count', str(alertCount))
                                self.__window.setProperty('Alerts.IsFetched', 'true')
                            else:
                                alertCount = 0
                                self.__window.clearProperty('Alerts.IsFetched')
                        else:
                            alertCount = 0
                            self.__window.clearProperty('Alerts.IsFetched')

                        # ---Clear unused alert properties
                        for alertNum in range(alertCount +1, MAX_ALERTS +1):
                            self.__clearAlert(alertNum)

                        # ---Maps
                        if includeTwcMaps or includeOwmMaps:

                            mapJson = json.loads('{}')
                            mapJson['zoom'] = self.__addon.getSettingInt('map-zoom')
                            mapJson['twcKey'] = self.__twcApiKey
                            mapJson['owmKey'] = self.__addon.getSettingString('owm-api-key')
                            mapJson['latitude'] = float(locationDetails['latitude'])
                            mapJson['longitude'] = float(locationDetails['longitude'])
                            mapJson['showErrorPopups'] = self.__showErrorPopups

                            twcLayers = []
                            owmLayers = []

                            if includeTwcMaps:

                                if self.__addon.getSettingBool('include-twc-precip-24hr'):
                                    twcLayers.append({'layer': 'precip24hr', 'name': self.__addon.getLocalizedString(32267)})

                                if self.__addon.getSettingBool('include-twc-temp'):
                                    twcLayers.append({'layer': 'temp', 'name': self.__addon.getLocalizedString(32252)})

                                if self.__addon.getSettingBool('include-twc-feel'):
                                    twcLayers.append({'layer': 'feelsLike', 'name': self.__addon.getLocalizedString(32264)})

                                if self.__addon.getSettingBool('include-twc-wind'):
                                    twcLayers.append({'layer': 'windSpeed', 'name': self.__addon.getLocalizedString(32253)})

                                if self.__addon.getSettingBool('include-twc-sat'):
                                    twcLayers.append({'layer': 'sat', 'name': self.__addon.getLocalizedString(32262)})

                                if self.__addon.getSettingBool('include-twc-radar'):
                                    twcLayers.append({'layer': 'radar', 'name': self.__addon.getLocalizedString(32261)})

                                if self.__addon.getSettingBool('include-twc-satrad'):
                                    twcLayers.append({'layer': 'satrad', 'name': self.__addon.getLocalizedString(32263)})

                                if self.__addon.getSettingBool('include-twc-uv'):
                                    twcLayers.append({'layer': 'uv', 'name': self.__addon.getLocalizedString(32265)})

                            if includeOwmMaps:

                                owmApiKey = self.__addon.getSettingString('owm-api-key')

                                if owmApiKey == '':

                                    log('*** %s *** OpenWeatherMap API KEY NOT ENTERED' % self.__addon.getAddonInfo('id'), LOGERROR)

                                    if self.__showErrorPopups:
                                        Dialog().ok(self.__addon.getAddonInfo('name'), self.__addon.getLocalizedString(32213))

                                else:
                                    
                                    if self.__addon.getSettingBool('include-owm-precip'):
                                        owmLayers.append({'layer': 'precipitation', 'name': self.__addon.getLocalizedString(32250)})

                                    if self.__addon.getSettingBool('include-owm-clouds'):
                                        owmLayers.append({'layer': 'clouds', 'name': self.__addon.getLocalizedString(32251)})

                                    if self.__addon.getSettingBool('include-owm-temp'):
                                        owmLayers.append({'layer': 'temp', 'name': self.__addon.getLocalizedString(32252)})

                                    if self.__addon.getSettingBool('include-owm-wind'):
                                        owmLayers.append({'layer': 'wind', 'name': self.__addon.getLocalizedString(32253)})

                                    if self.__addon.getSettingBool('include-owm-pressure'):
                                        owmLayers.append({'layer': 'pressure', 'name': self.__addon.getLocalizedString(32254)})


                            # ---We have gathered all the map layers requested, send them to the background script
                            if len(twcLayers) + len(owmLayers) > 0:

                                mapJson['twc'] = twcLayers
                                mapJson['owm'] = owmLayers

                            args = urlencode({'json': json.dumps(mapJson)})
                            
                            executebuiltin('RunAddon(script.weather.elemental.maps,' + args + ')')

                        else:

                            # ---Clear any previous layer forecasts
                            for num in range(1, 21):
                                self.__window.clearProperty('Map.%i.Area' % num)
                                self.__window.clearProperty('Map.%i.Layer' % num)
                                self.__window.clearProperty('Map.%i.Heading' % num)
                                self.__window.clearProperty('Map.%i.Legend' % num)

                            self.__window.clearProperty('Map.IsFetched')

                    except ApiConnectionException as e:

                        alertCount = 0
                        
                        log('*** %s *** FORECAST API CONNECTION FAIL: %s' % (self.__addon.getAddonInfo('id'), e.message()), LOGERROR)

                        if self.__showErrorPopups:
                            Dialog().ok(self.__addon.getAddonInfo('name'), self.__addon.getLocalizedString(32217))
                    
                    except ApiException as e:
                
                        raise e

                else:
                    alertCount = 0
                
                self.__window.setProperty('WeatherProvider', self.__addon.getLocalizedString(32204))
                self.__window.setProperty('WeatherProviderLogo', join(self.__addon.getAddonInfo('path'), 'resources', 'The_Weather_Channel_logo.png'))

            else:
                 alertCount = 0
                 
            # ---Tell Kodi what locations are available
            locationNum = 1
            currentLocation = self.__addon.getSettingString('loc1')
            showAlertFlair = self.__addon.getSettingBool('show-alert-flair')
            mode = int(self.__mode)
            while currentLocation != '':

                if showAlertFlair and locationNum == mode:
                    if alertCount == 1: 
                        alertFlair = ': [COLOR %s]%s[/COLOR]' % (self.__addon.getSettingString('alert-flair-colour'), self.__addon.getLocalizedString(32272))
                    elif alertCount > 1:
                        alertFlair = ': [COLOR %s]%s[/COLOR]' % (self.__addon.getSettingString('alert-flair-colour'), (self.__addon.getLocalizedString(32273) % alertCount))
                    else:
                        alertFlair = ''
                else:
                    alertFlair = ''

                self.__window.setProperty('Location%s' % locationNum, currentLocation + alertFlair)
                locationNum += 1
                if locationNum == 11:
                    break

                currentLocation = self.__addon.getSettingString('loc' + str(locationNum))

            self.__window.setProperty('Locations', str(locationNum -1))

    def __current(self, conditions, locationDetails):

        # ---Default Kodi weather properties
        self.__window.setProperty('Current.Condition', conditions['conditionsMedium'])
        self.__window.setProperty('Current.Temperature', str(conditions['currentTemp']))
        self.__window.setProperty('Current.Wind', str(conditions['windSpeed']))
        self.__window.setProperty('Current.WindDirection', conditions['windDirection'])
        self.__window.setProperty('Current.Humidity', str(conditions['humidity']))
        self.__window.setProperty('Current.FeelsLike', str(conditions['feelsLike']))
        self.__window.setProperty('Current.DewPoint', str(conditions['dewPoint']))
        self.__window.setProperty('Current.UvIndex', str(conditions['uvIndex']) + ' (' + conditions['uvDescription'] + ')')

        conditionCode = conditions['iconCode']
        conditionIcon = conditionCode + '.png'
        self.__window.setProperty('Current.ConditionIcon', conditionIcon)
        self.__window.setProperty('Current.FanartCode', conditionCode)

        # ---Extended weather properties
        self.__window.setProperty('Current.IsFetched', 'true')
        self.__window.setProperty('Current.OutlookIcon', conditionIcon)
        self.__window.setProperty('Current.Visibility', str(conditions['visibility']))
        self.__window.setProperty('Current.Pressure', str(conditions['pressure']))
        self.__window.setProperty('Current.PressureChange', str(conditions['pressureChange']))
        self.__window.setProperty('Current.SeaLevel', str(conditions['seaLevel']))

        precipHours = self.__addon.getSettingInt('precipitation-hours')
        precipKey = 'precipitation%ihr' % precipHours
        precipDuration = self.__addon.getLocalizedString(32275 if precipHours == 1 else (32276 if precipHours == 6 else 32277)).lower()

        snowHours = self.__addon.getSettingInt('snow-hours')
        snowKey = 'precipitation%ihr' % snowHours
        snowDuration = self.__addon.getLocalizedString(32275 if snowHours == 1 else (32276 if snowHours == 6 else 32277)).lower()

        if self.__imperialUnits:
            self.__window.setProperty('Current.Precipitation', '%.2f in (%s)' % ((conditions[precipKey] / 25.4), precipDuration))
            self.__window.setProperty('Current.Snow', '%.2f in (%s)' % ((conditions[snowKey] / 25.4), snowDuration))
        else:
            self.__window.setProperty('Current.Precipitation','%.2f mm (%s)' % ((conditions[precipKey]), precipDuration))
            self.__window.setProperty('Current.Snow', '%.2f cm (%s)' % ((conditions[snowKey]), snowDuration))

        self.__window.setProperty('Current.Cloudiness', conditions['cloudCover'])
        windGust = conditions['windGust']
        if windGust:
            self.__window.setProperty('Current.WindGust', str(windGust))
        else:
            self.__window.clearProperty('Current.WindGust')

        self.__window.setProperty('Today.IsFetched', 'true')
        self.__window.setProperty('Today.Sunrise', conditions['sunRise'].format(self.__timeFormat))
        self.__window.setProperty('Today.Sunset', conditions['sunSet'].format(self.__timeFormat))

        self.__window.setProperty('Forecast.IsFetched', 'true')
        self.__window.setProperty('Forecast.City', locationDetails['city'])
        self.__window.setProperty('Forecast.Country', locationDetails['country'])
        self.__window.setProperty('Forecast.Latitude', locationDetails['latitude'])
        self.__window.setProperty('Forecast.Longitude', locationDetails['latitude'])
        self.__window.setProperty('Forecast.Updated', conditions['updated'].format(self.__timeFormat))

    def __daily(self, dayNum, day, outlookElement):

        when = day['when']

        try:

            dow = int(when.format('d'))
            dayName = day['dayName']
            self.__window.setProperty('Day%i.Title'          % dayNum, dayName)
            self.__window.setProperty('Daily.%i.ShortDay'    % dayNum, getLocalizedString(dow + 40))
            self.__window.setProperty('Daily.%i.LongDay'     % dayNum, getLocalizedString(dow + 10))
            self.__window.setProperty('Daily.%i.ShortDate'   % dayNum, when.format('D'))
            self.__window.setProperty('Daily.%i.LongDate'    % dayNum, when.format('D'))

        except:

            # ---Must be a literal day name instead of a date
            self.__window.setProperty('Day%i.Title'          % dayNum, when)
            self.__window.setProperty('Daily.%i.ShortDay'    % dayNum, when)
            self.__window.setProperty('Daily.%i.LongDay'     % dayNum, when)
            self.__window.clearProperty('Daily.%i.ShortDate' % dayNum)
            self.__window.clearProperty('Daily.%i.LongDate'  % dayNum)

        highTemp = day['highTemp']
        if highTemp:
            highTemp
            self.__window.setProperty('Day%i.HighTemp'       % dayNum, highTemp)
            self.__window.setProperty('Daily.%i.HighTemperature' % dayNum, highTemp)
        else:
            self.__window.clearProperty('Day%i.HighTemp'     % dayNum)
            self.__window.clearProperty('Daily.%i.HighTemperature' % dayNum)

        self.__window.setProperty('Day%i.LowTemp'            % dayNum, day['lowTemp'] + '°')
        self.__window.setProperty('Day%i.Outlook'            % dayNum, day[outlookElement])

        conditionCode = day['iconCode']

        self.__window.setProperty('Day%i.OutlookIcon'        % dayNum, conditionCode + '.png')
        self.__window.setProperty('Day%i.FanartCode'         % dayNum, conditionCode)

        self.__window.setProperty('Daily.%i.LowTemperature'  % dayNum, day['lowTemp'] )
        self.__window.setProperty('Daily.%i.Outlook'         % dayNum, day[outlookElement])
        self.__window.setProperty('Daily.%i.OutlookIcon'     % dayNum, conditionCode + '.png')
        self.__window.setProperty('Daily.%i.FanartCode'      % dayNum, conditionCode)
        self.__window.setProperty('Daily.%i.Humidity'        % dayNum, day['humidity']+ '%')
        self.__window.setProperty('Daily.%i.WindDirection'   % dayNum, day['windDirection'])
        self.__window.setProperty('Daily.%i.WindDegree'      % dayNum, day['windDegree'])
        self.__window.setProperty('Daily.%i.WindSpeed'       % dayNum, day['windSpeed'])
        self.__window.setProperty('Daily.%i.Precipitation'   % dayNum, day['precipitation'] + '%')
        self.__window.clearProperty('Daily.%i.DewPoint'      % dayNum)

        self.__window.setProperty('Daily.%i.Narrative'       % dayNum, day['narrative'])
        self.__window.setProperty('Daily.%i.Cloudiness'      % dayNum, day['cloudiness'] + '%')
        self.__window.setProperty('Daily.%i.UVIndex'         % dayNum, str(day['uvIndex']) + ' (' + day['uvDescription'] + ')')

        self.__window.setProperty('Daily.%i.SunRise'         % dayNum, day['sunRise'].format(self.__timeFormat))
        self.__window.setProperty('Daily.%i.SunSet'          % dayNum, day['sunSet'].format(self.__timeFormat))

        self.__window.setProperty('Daily.%i.MoonPhase'       % dayNum, day['moonPhase'])
        self.__window.setProperty('Daily.%i.MoonPhaseCode'   % dayNum, day['moonPhaseCode'])

        moonRise = day['moonRise']
        if moonRise:
            self.__window.setProperty('Daily.%i.MoonRise'    % dayNum, day['moonRise'].format(self.__timeFormat))
        else:
            self.__window.clearProperty('Daily.%i.MoonRise'  % dayNum)

        moonSet = day['moonSet']
        if moonSet:
            self.__window.setProperty('Daily.%i.MoonSet'     % dayNum, day['moonSet'].format(self.__timeFormat))
        else:
            self.__window.clearProperty('Daily.%i.MoonSet'   % dayNum)

        if self.__imperialUnits:
            self.__window.setProperty('Daily.%i.RainDepth'   % dayNum, str(day['rainDepth'] / 25.4) + ' mm')
            self.__window.setProperty('Daily.%i.SnowDepth'   % dayNum, str(day['snowDepth'] / 2.54) + ' cm')
        else:
            self.__window.setProperty('Daily.%i.RainDepth'   % dayNum, str(day['rainDepth']) + ' mm')
            self.__window.setProperty('Daily.%i.SnowDepth'   % dayNum, str(day['snowDepth']) + ' cm')

    def __clearDaily(self, dayNum):

        self.__window.clearProperty('Day%i.Title'              % dayNum)
        self.__window.clearProperty('Daily.%i.ShortDay'        % dayNum)
        self.__window.clearProperty('Daily.%i.LongDay'         % dayNum)
        self.__window.clearProperty('Daily.%i.ShortDate'       % dayNum)
        self.__window.clearProperty('Daily.%i.LongDate'        % dayNum)
        self.__window.clearProperty('Day%i.Title'              % dayNum)
        self.__window.clearProperty('Day%i.HighTemp'           % dayNum)
        self.__window.clearProperty('Daily.%i.HighTemperature' % dayNum)
        self.__window.clearProperty('Day%i.LowTemp'            % dayNum)
        self.__window.clearProperty('Day%i.Outlook'            % dayNum)
        self.__window.clearProperty('Day%i.OutlookIcon'        % dayNum)
        self.__window.clearProperty('Day%i.FanartCode'         % dayNum)
        self.__window.clearProperty('Daily.%i.LowTemperature'  % dayNum)
        self.__window.clearProperty('Daily.%i.Outlook'         % dayNum)
        self.__window.clearProperty('Daily.%i.OutlookIcon'     % dayNum)
        self.__window.clearProperty('Daily.%i.FanartCode'      % dayNum)
        self.__window.clearProperty('Daily.%i.Humidity'        % dayNum)
        self.__window.clearProperty('Daily.%i.WindDirection'   % dayNum)
        self.__window.clearProperty('Daily.%i.WindDegree'      % dayNum)
        self.__window.clearProperty('Daily.%i.WindSpeed'       % dayNum)
        self.__window.clearProperty('Daily.%i.Precipitation'   % dayNum)
        self.__window.clearProperty('Daily.%i.DewPoint'        % dayNum)
        self.__window.clearProperty('Daily.%i.Narrative'       % dayNum)
        self.__window.clearProperty('Daily.%i.Cloudiness'      % dayNum)
        self.__window.clearProperty('Daily.%i.UVIndex'         % dayNum)
        self.__window.clearProperty('Daily.%i.SunRise'         % dayNum)
        self.__window.clearProperty('Daily.%i.SunSet'          % dayNum)
        self.__window.clearProperty('Daily.%i.MoonPhase'       % dayNum)
        self.__window.clearProperty('Daily.%i.MoonPhaseCode'   % dayNum)
        self.__window.clearProperty('Daily.%i.MoonRise'        % dayNum)
        self.__window.clearProperty('Daily.%i.MoonSet'         % dayNum)
        self.__window.clearProperty('Daily.%i.RainDepth'       % dayNum)
        self.__window.clearProperty('Daily.%i.SnowDepth'       % dayNum)

    def __hourly(self, hourNum, hour):

        conditionCode = hour['iconCode']

        when = hour['when']
        day = when.format(' D')

        dayNum = int(hour['when'].format('d'))

        humidity = hour['humidity']
        temperature = hour['temperature']

        self.__window.setProperty('Hourly.%i.Time'            % hourNum, when.format(self.__timeFormat))
        self.__window.setProperty('Hourly.%i.LongDate'        % hourNum, getLocalizedString(dayNum + 10) + day)
        self.__window.setProperty('Hourly.%i.ShortDate'       % hourNum, getLocalizedString(dayNum + 40) + day)
        self.__window.setProperty('Hourly.%i.Temperature'     % hourNum, str(temperature))
        self.__window.setProperty('Hourly.%i.FeelsLike'       % hourNum, hour['feelsLike'])
        self.__window.setProperty('Hourly.%i.Outlook'         % hourNum, hour['conditions'])
        self.__window.setProperty('Hourly.%i.OutlookIcon'     % hourNum, conditionCode + '.png')
        self.__window.setProperty('Hourly.%i.FanartCode'      % hourNum, conditionCode)
        self.__window.setProperty('Hourly.%i.Humidity'        % hourNum, str(humidity) + "%")
        self.__window.setProperty('Hourly.%i.Precipitation'   % hourNum, hour['precipitation'] + "%")
        self.__window.setProperty('Hourly.%i.WindDirection'   % hourNum, hour['windDirection'])
        self.__window.setProperty('Hourly.%i.WindDegree'      % hourNum, hour['windDegree'] + '°')
        self.__window.setProperty('Hourly.%i.WindSpeed'       % hourNum, hour['windSpeed'])
        self.__window.setProperty('Hourly.%i.Cloudiness'      % hourNum, hour['cloudiness'] + '%')

        if self.__imperialUnits:
            self.__window.setProperty('Hourly.%i.RainDepth'       % hourNum, str(hour['rain'] / 25.4) + ' in')
            self.__window.setProperty('Hourly.%i.SnowDepth'       % hourNum, str(hour['snow'] / 2.54) + ' in')
        else:
            self.__window.setProperty('Hourly.%i.RainDepth'       % hourNum, str(hour['rain']) + ' mm')
            self.__window.setProperty('Hourly.%i.SnowDepth'       % hourNum, str(hour['snow']) + ' cm')

    def __clearHourly( self, hourNum):

        self.__window.clearProperty('Hourly.%i.Time' % hourNum)
        self.__window.clearProperty('Hourly.%i.LongDate' % hourNum)
        self.__window.clearProperty('Hourly.%i.ShortDate' % hourNum)
        self.__window.clearProperty('Hourly.%i.Temperature' % hourNum)
        self.__window.clearProperty('Hourly.%i.FeelsLike' % hourNum)
        self.__window.clearProperty('Hourly.%i.Outlook' % hourNum)
        self.__window.clearProperty('Hourly.%i.OutlookIcon' % hourNum)
        self.__window.clearProperty('Hourly.%i.FanartCode' % hourNum)
        self.__window.clearProperty('Hourly.%i.Humidity' % hourNum)
        self.__window.clearProperty('Hourly.%i.Precipitation' % hourNum)
        self.__window.clearProperty('Hourly.%i.WindDirection' % hourNum)
        self.__window.clearProperty('Hourly.%i.WindDegree' % hourNum)
        self.__window.clearProperty('Hourly.%i.WindSpeed' % hourNum)
        self.__window.clearProperty('Hourly.%i.Cloudiness' % hourNum)
        self.__window.clearProperty('Hourly.%i.RainDepth' % hourNum)
        self.__window.clearProperty('Hourly.%i.SnowDepth' % hourNum)

    def __weekend(self, dayNum, forecast, outlookElement):

        when = forecast['when']

        self.__window.setProperty('Weekend.%i.LongDay'               % dayNum, when.format('dddd', locale=self.__arrowLanguageCode))
        self.__window.setProperty('Weekend.%i.ShortDay'              % dayNum, when.format('dddd', locale=self.__arrowLanguageCode))
        self.__window.setProperty('Weekend.%i.LongDate'              % dayNum, when.format('MMMM D', locale=self.__arrowLanguageCode))
        self.__window.setProperty('Weekend.%i.ShortDate'             % dayNum, when.format('MMM D', locale=self.__arrowLanguageCode))

        self.__window.setProperty('Weekend.%i.Outlook'               % dayNum, forecast[outlookElement])
        self.__window.setProperty('Weekend.%i.LongOutlookDay'        % dayNum, forecast['conditionsDay'])
        self.__window.setProperty('Weekend.%i.LongOutlookNight'      % dayNum, forecast['conditionsNight'])
        self.__window.setProperty('Weekend.%i.OutlookIcon'           % dayNum, forecast['iconCode'] + '.png')
        self.__window.setProperty('Weekend.%i.FanartCode'            % dayNum, forecast['iconCode'])

        highTemp = forecast['highTemp']
        if highTemp != '':
            self.__window.setProperty('Weekend.%i.HighTemperature'   % dayNum, highTemp)
        else:
            self.__window.clearProperty('Weekend.%i.HighTemperature' % dayNum)

        lowTemp = forecast['lowTemp']
        if lowTemp != '':
            self.__window.setProperty('Weekend.%i.LowTemperature'    % dayNum, lowTemp)
        else:
            self.__window.clearProperty('Weekend.%i.LowTemperature'  % dayNum)

        self.__window.setProperty('Weekend.%i.WindSpeed'             % dayNum, forecast['windSpeed'])
        self.__window.setProperty('Weekend.%i.WindDirection'         % dayNum, forecast['windDirection'])

        rainDepth = forecast['rainDepth']
        if self.__imperialUnits:
            self.__window.setProperty('Weekend.%i.Rain'             % dayNum, str(rainDepth / 25.4) + ' in')
            self.__window.setProperty('Weekend.%i.Precipitation'    % dayNum, str(rainDepth / 25.4) + ' in')
            self.__window.setProperty('Weekend.%i.Snow'             % dayNum, str(forecast['snowDepth'] / 2.54) + ' in')
        else:
            self.__window.setProperty('Weekend.%i.Rain'             % dayNum, str(rainDepth) + ' mm')
            self.__window.setProperty('Weekend.%i.Precipitation'    % dayNum, str(rainDepth) + ' mm')
            self.__window.setProperty('Weekend.%i.Snow'             % dayNum, str(forecast['snowDepth']) + ' cm')

        self.__window.setProperty('Weekend.%i.ChancePrecipitation'  % dayNum, str(forecast['precipChance']) + '%')
        self.__window.setProperty('Weekend.%i.Humidity'             % dayNum, str(forecast['humidity']) + '%')
        self.__window.setProperty('Weekend.%i.Cloudiness'           % dayNum, str(forecast['cloudiness']) + '%')

        # Weekend.%i.MaxWind
        # Weekend.%i.ShortWindDirection
        # Weekend.%i.WindDegree
        # Weekend.%i.DewPoint
        # Weekend.%i.MinHumidity
        # Weekend.%i.MaxHumidity

    def __clearWeekend(self, dayNum):

        self.__window.clearProperty('Weekend.%i.LongDay'              % dayNum)
        self.__window.clearProperty('Weekend.%i.ShortDay'             % dayNum)
        self.__window.clearProperty('Weekend.%i.LongDate'             % dayNum)
        self.__window.clearProperty('Weekend.%i.ShortDate'            % dayNum)
        self.__window.clearProperty('Weekend.%i.Outlook'              % dayNum)
        self.__window.clearProperty('Weekend.%i.LongOutlookDay'       % dayNum)
        self.__window.clearProperty('Weekend.%i.LongOutlookNight'     % dayNum)
        self.__window.clearProperty('Weekend.%i.OutlookIcon'          % dayNum)
        self.__window.clearProperty('Weekend.%i.FanartCode'           % dayNum)
        self.__window.clearProperty('Weekend.%i.HighTemperature'      % dayNum)
        self.__window.clearProperty('Weekend.%i.LowTemperature'       % dayNum)
        self.__window.clearProperty('Weekend.%i.WindSpeed'            % dayNum)
        self.__window.clearProperty('Weekend.%i.WindDirection'        % dayNum)
        self.__window.clearProperty('Weekend.%i.Rain'                 % dayNum)
        self.__window.clearProperty('Weekend.%i.Precipitation'        % dayNum)
        self.__window.clearProperty('Weekend.%i.Snow'                 % dayNum)
        self.__window.clearProperty('Weekend.%i.ChancePrecipitation'  % dayNum)
        self.__window.clearProperty('Weekend.%i.Humidity'             % dayNum)
        self.__window.clearProperty('Weekend.%i.Cloudiness'           % dayNum)

    def __36hour(self, dayPartNum, dayPart, outlookElement):

        self.__window.setProperty('36Hour.%i.Heading' % dayPartNum, dayPart['name'])
        self.__window.setProperty('36Hour.%i.FanartCode' % dayPartNum, dayPart['iconCode'])
        self.__window.setProperty('36Hour.%i.TemperatureHeading' % dayPartNum, getLocalizedString(391 if dayPart['dayOrNight'] == 'N' else 393))
        self.__window.setProperty('36Hour.%i.Temperature' % dayPartNum, dayPart['temperature'])
        self.__window.setProperty('36Hour.%i.FeelsLike' % dayPartNum, dayPart['feelsLike'])
        self.__window.setProperty('36Hour.%i.Outlook' % dayPartNum, dayPart[outlookElement])
        self.__window.setProperty('36Hour.%i.Cloudiness' % dayPartNum, dayPart['cloudiness'] + '%')

        if self.__imperialUnits:
            self.__window.setProperty('36Hour.%i.Precipitation' % dayPartNum, str(dayPart['precipitation'] / 25.4) + ' in')
        else:
            self.__window.setProperty('36Hour.%i.Precipitation' % dayPartNum, str(dayPart['precipitation']) + ' mm')

    def __clear36hour(self, dayPartNum):

        self.__window.clearProperty('36Hour.%i.Heading' % dayPartNum)
        self.__window.clearProperty('36Hour.%i.FanartCode' % dayPartNum)
        self.__window.clearProperty('36Hour.%i.TemperatureHeading' % dayPartNum)
        self.__window.clearProperty('36Hour.%i.Temperature' % dayPartNum)
        self.__window.clearProperty('36Hour.%i.FeelsLike' % dayPartNum)
        self.__window.clearProperty('36Hour.%i.Outlook' % dayPartNum)
        self.__window.clearProperty('36Hour.%i.Precipitation' % dayPartNum)
        self.__window.clearProperty('36Hour.%i.Cloudiness' % dayPartNum)

    def __alert(self, alertNum, alert):

        self.__window.setProperty('Alerts.%i.Status' % alertNum, alert['significance'])
        self.__window.setProperty('Alerts.%i.MessageType' % alertNum, alert['messageType'])
        self.__window.setProperty('Alerts.%i.Category' % alertNum, alert['category'])
        self.__window.setProperty('Alerts.%i.Severity' % alertNum, alert['severity'])
        self.__window.setProperty('Alerts.%i.Certainty' % alertNum, alert['certainty'])
        self.__window.setProperty('Alerts.%i.Urgency' % alertNum, alert['urgency'])
        self.__window.setProperty('Alerts.%i.Event' % alertNum, alert['eventDescription'])
        self.__window.setProperty('Alerts.%i.Headline' % alertNum, alert['headline'])
        self.__window.setProperty('Alerts.%i.Response' % alertNum, alert['response'])
        self.__window.setProperty('Alerts.%i.Significance' % alertNum, alert['significance'])
        self.__window.setProperty('Alerts.%i.StartDate' % alertNum, alert['effectiveTime'].format(self.__dateFormat + ' ' + self.__timeFormat))
        self.__window.setProperty('Alerts.%i.EndDate' % alertNum, alert['expireTime'].format(self.__dateFormat + ' ' + self.__timeFormat))

        description = alert['description']
        if description:
            self.__window.setProperty('Alerts.%i.Description' % alertNum, description)
            self.__window.setProperty('Alerts.%i.Message' % alertNum, description)
        else:
            self.__window.clearProperty('Alerts.%i.Description')
            self.__window.clearProperty('Alerts.%i.Message')

        instruction = alert['instruction']
        if instruction:
            self.__window.setProperty('Alerts.%i.Instruction' % alertNum, instruction)
        else:
            self.__window.clearProperty('Alerts.%i.Instruction')

    def __clearAlert(self, alertNum):

        self.__window.clearProperty('Alerts.%i.Status' % alertNum)
        self.__window.clearProperty('Alerts.%i.MessageType' % alertNum)
        self.__window.clearProperty('Alerts.%i.Category' % alertNum)
        self.__window.clearProperty('Alerts.%i.Severity' % alertNum)
        self.__window.clearProperty('Alerts.%i.Certainty' % alertNum)
        self.__window.clearProperty('Alerts.%i.Urgency' % alertNum)
        self.__window.clearProperty('Alerts.%i.Headline' % alertNum)
        self.__window.clearProperty('Alerts.%i.Response' % alertNum)
        self.__window.clearProperty('Alerts.%i.Significance' % alertNum)
        self.__window.clearProperty('Alerts.%i.StartDate' % alertNum)
        self.__window.clearProperty('Alerts.%i.EndDate' % alertNum)
        self.__window.clearProperty('Alerts.%i.Description' % alertNum)
        self.__window.clearProperty('Alerts.%i.Message')
        self.__window.clearProperty('Alerts.%i.Instruction')

    def __locationTypeDetails(self, locationType):

        if locationType == 'postal':
            stringNum = 32238
            icon = 'mailbox.png'
        elif locationType == 'poi':
            stringNum = 32239
            icon = 'eiffel-tower.png'
        elif locationType == 'city':
            stringNum = 32235
            icon = 'city.png'
        elif locationType == 'neighborhood':
            stringNum = 32237
            icon = 'neighborhood.png'
        else:
            stringNum = 32236
            icon = 'locality.png'

        return {
            'iconPath': join(self.__addon.getAddonInfo('path'), 'resources', icon),
            'localizedName': self.__addon.getLocalizedString(stringNum)
        }
    
    def __setLocation(self, locationStr):

        # ---Ask user for search string
        keyboard = Keyboard('', self.__addon.getLocalizedString(32110 + int(locationStr)))
        keyboard.doModal()
        if keyboard.isConfirmed():
            
            searchTerm = keyboard.getText()

            if searchTerm == '':
                # ---Search term is empty so ask the user whether to delete this location
                if Dialog().yesno(self.__addon.getLocalizedString(32201), self.__addon.getLocalizedString(32202)):

                    # ---User wants to delete this location
                    self.__deleteLocation(locationStr)

            else:
                try:
                    # ---Get all locations matching the search term
                    locations = Api(self.__twcApiKey).searchLocation(searchTerm)

                    if not locations:

                        # ---No matches found... alert user
                        Dialog().ok('', self.__addon.getLocalizedString(32203) % searchTerm)

                    else:

                        # ---Found at least one match, ask user which one to use
                        items = []
                        for location in locations:

                            locationTypeDetails = self.__locationTypeDetails(location['type'])
                            listItem = ListItem(location['address'], '%s\n%.3f, %.3f' % (
                                locationTypeDetails['localizedName'],
                                location['latitude'], 
                                location['longitude'])

                            , offscreen=True)

                            listItem.setArt({'icon': locationTypeDetails['iconPath']})
                            items.append(listItem)

                        selected = Dialog().select(self.__addon.getLocalizedString(32208), items, useDetails=self.__showSearchCoordinates)

                        # ---Did the user pick one?
                        if selected != -1:

                            # ---Yes, give user a chance to edit the name
                            name = Dialog().input('Location Name', locations[selected]['address'])

                            if name != '':
                                
                                # ---User entered or accepted a name for the location so save it 
                                locationDetails = ('{'
                                    '"locationID": "%s",'
                                    '"latitude": "%.3f",'
                                    '"longitude": "%.3f",'
                                    '"city": "%s",'
                                    '"country": "%s"'
                                    '}'

                                ) % (

                                    locations[selected]['locationID'],
                                    locations[selected]['latitude'],
                                    locations[selected]['longitude'],
                                    locations[selected]['city'],
                                    locations[selected]['country'],
                                )
                                
                                self.__addon.setSettingString('loc' + locationStr, name)
                                self.__addon.setSettingString('loc' + locationStr + 'details', locationDetails)

                except ApiException as e:

                    # ---The location search API call returned a status other than 200
                    statusCode = e.statusCode()

                    if statusCode == 401:
                        # ---The location search API call connection failed authorization
                        Dialog().ok(self.__addon.getLocalizedString(32209), self.__addon.getLocalizedString(32210))
                    else:
                        # ---The location search API call status was not 200 or 401
                        log("*** %s *** SEARCH API CALL ERROR: HTTP status '%i'. Url = '%s'" % (self.__addon.getAddonInfo('id'), statusCode, e.url()), LOGERROR)
                        Dialog().ok(self.__addon.getLocalizedString(32211), self.__addon.getLocalizedString(32212) % statusCode)

                except ApiConnectionException as e:

                    # ---The location search API call connection failed
                    log('*** %s *** SEARCH API CONNECTION FAIL: %s' % (self.__addon.getAddonInfo('id'), e.message()), LOGERROR)
                    Dialog().ok(self.__addon.getLocalizedString(32215),self.__addon.getLocalizedString(32216))

    def __deleteLocation(self, location):

        if location == '10':

            # ---Just delete the last location, no need to shift anything up
            self.__addon.setSetting('loc10', '')
            self.__addon.setSetting('loc10details', '')

        else:
            i = int(location)

            currentNum = str(i)
            nextNum = str(i + 1)
            nextLocation = self.__addon.getSettingString('loc' + str(i + 1))

            # ---Move subsequent locations down until we find the first empty location or reach the 9th location 
            while i < 10 and nextLocation != '':
        
                # ---Move the next location down into the current location
                self.__addon.setSetting('loc' + currentNum, nextLocation)
                self.__addon.setSetting('loc' + currentNum + 'details', self.__addon.getSettingString('loc' + nextNum + 'details'))

                i += 1           
                if i < 10:
                    currentNum = str(i)
                    nextNum = str(i + 1)
                    nextLocation = self.__addon.getSettingString('loc' + nextNum)
                else:
                    break

            # ---Clear the final location
            self.__addon.setSetting('loc' + currentNum, '')
            self.__addon.setSetting('loc' + currentNum + 'details', '')

    def __help(self, topic):

        helpHeading = self.__addon.getLocalizedString(32244)

        if topic == 'owm-api-key':

            dialog = Dialog().ok(helpHeading,self.__addon.getLocalizedString(32243))

