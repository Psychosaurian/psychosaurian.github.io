import sys
from resources.lib.plugin import Plugin

if __name__ == '__main__':

    Plugin(sys.argv).route()
