# Elemental Weather (weather.elemental)

Complemento do provedor de clima Kodi para The Weather Channel com cobertura mundial atual, diária (3, 5, 7, 10 ou 15 dias), de hora em hora (2, 3, 10 ou 15 horas), 36 horas (esta manhã, esta noite , amanhã de manhã ou hoje à noite, amanhã de manhã, amanhã à noite) e previsões para o fim de semana. Ele também pode fornecer mapas meteorológicos do The Weather Channel e/ou OpenWeatherMap. Alertas e avisos meteorológicos também estão disponíveis.

## Por que usar o Clima Elemental?

Desde o lançamento do Kodi Matrix, que não funcionaria mais com provedores de clima mais antigos do Kodi Leia e anteriores, não houve complementos de provedores de clima com boa cobertura mundial. A maioria dos usuários optou pelo Multi Weather, que combina previsões do Yahoo, Weatherbit e OpenWeatherMap, mas a cobertura das previsões para áreas de menor população ainda é fraca, apesar das múltiplas fontes. Embora as skins Kodi muitas vezes suportem períodos de previsão adicionais além de apenas de hora em hora e diariamente, nenhum dos provedores de clima disponíveis nos repositórios oficiais do Kodi retorna todos os tipos de previsão que são capazes de exibir. Além disso, embora o Multi Weather possa recuperar mapas meteorológicos do OpenWeatherMap, nenhum deles oferece mapas do The Weather Channel, que incluem mapas de satélite e RADAR, nenhum dos quais disponível no OpenWeatherMap.

Se você deseja a cobertura mundial, a variedade de períodos de previsão e os mapas disponíveis no The Weather Channel, então você deseja o Elemental Weather.

## Requisitos

Este complemento requer Kodi 19.0 (Matrix) ou posterior. Os mapas meteorológicos do Weather Channel são integrados, mas se você também quiser mapas OpenWeatherMap, precisará se inscrever para obter uma chave de API OpenWeatherMap gratuita (detalhes abaixo).

## Suporte para a pele

Muitas skins Kodi populares tratam o clima como uma reflexão tardia. Embora a maioria o faça, alguns nem exibem o clima, e aqueles que o fazem geralmente mostram apenas as condições atuais e as previsões diárias e de hora em hora. Elemental Weather foi projetado para fornecer todos os atributos de previsão estendidos fornecidos por todos os provedores de clima disponíveis nos repositórios oficiais do Kodi, o que significa que deve funcionar com qualquer skin popular, independentemente do provedor de clima para o qual o skin foi otimizado.

Como mencionado anteriormente, o Elemental Weather fornece uma gama completa de períodos e tipos de previsão, mas dependendo da skin Kodi que você está usando, algumas ou todas essas previsões podem não estar disponíveis para você. Além disso, embora o Elemental Weather possa fornecer previsões diárias com até 15 dias de antecedência e previsões de hora em hora com até 15 horas, sua skin Kodi pode não mostrar todas essas horas e dias. Por exemplo, é comum que os skins mostrem apenas previsões de sete ou dez dias, mesmo que o addon do provedor retorne mais do que isso.

O Elemental Weather retornará alertas meteorológicos em dois formatos diferentes, mas sua skin Kodi pode não usar nenhum deles, portanto, mesmo se você ativar alertas meteorológicos nas configurações do Elemental Weather, você poderá não vê-los.

Se você ativar todos os tipos de mapas meteorológicos disponíveis no The Weather Channel e no OpenWeatherMap, o Elemental Weather pode fornecer até 13 mapas, mas nenhum dos skins populares testados mostraria mais de cinco deles. Isso pode mudar se este complemento ganhar popularidade, mas por enquanto suas únicas opções se você deseja um melhor suporte ao mapa é pedir ao seu desenvolvedor de skin favorito para atualizar seus skins, aprender como modificar o skin você mesmo ou procurar skins capazes de exibir mais de apenas cinco mapas.

## Configuração

Elemental Weather é altamente configurável, permitindo até dez locais de previsão. Se o seu skin não suportar todos os seus recursos, você poderá desativá-los individualmente ou reduzir o número de horas ou dias recuperados para reduzir o tráfego desnecessário da Internet. As configurações são divididas em quatro guias...

### Localizações

Aqui você pode inserir até dez locais para recuperar previsões. Clique em qualquer linha de localização e insira uma sequência de pesquisa. Se você inserir uma string de pesquisa vazia, será perguntado se deseja excluir o local que já está nesse slot.

Ao escolher um local desejado nos resultados da pesquisa, você terá a oportunidade de editar o nome do local. Depois de aceitar o nome de um local, a única maneira de alterá-lo é procurá-lo novamente.

### Geral

#### Resultados detalhados da pesquisa

Se ativado, os resultados da pesquisa de localização na guia anterior incluirão a latitude/longitude e o tipo de localização (ou seja, cidade/vila/vila, ponto de interesse, bairro, etc.). Se desativado, apenas o nome do local será mostrado nos resultados da pesquisa. O padrão é habilitado.

#### Mostrar pop-ups de erro

Os provedores meteorológicos são executados em segundo plano e normalmente não interagem com o usuário, exceto por meio da exibição do tempo. Se esta opção estiver habilitada, um pop-up exibirá erros na tela e os salvará no arquivo de log Kodi. Se desativado, os erros serão salvos apenas no arquivo de log. O padrão é desabilitado.

#### A precipitação de hoje

Isto permite definir o período de tempo usado para acumulação de precipitação. As opções são última hora, últimas 6 horas ou últimas 24 horas. O padrão é 24 horas.

#### A neve de hoje

O mesmo que para a precipitação de hoje, mas para acumulações de neve.

### Previsões

#### Diário

Selecione o número de dias fornecido pela previsão diária. As opções são 3, 5, 7, 10 ou 15 dias. O padrão é 7 dias.

#### Diário - Texto detalhado do Outlook

Se ativado, cada dia incluirá uma previsão detalhada. Dependendo do skin que você está usando, isso pode sobrecarregar a tela. Se desativado, a previsão será de apenas algumas palavras, como 'Ensolarado' ou 'Muito Nublado'. O padrão é desabilitado.

#### De hora em hora

Selecione o número de horas fornecido pela previsão horária. As opções são 2, 3, 10 ou 15 dias. O padrão é 10 horas.

#### De hora em hora - Texto detalhado do Outlook

O mesmo que para a previsão diária, mas para a previsão horária. O padrão é desabilitado.

#### 36 horas

Ative ou desative a previsão de 36 horas. O padrão é habilitado.

#### 36 horas - Texto detalhado do Outlook

O mesmo que para a previsão diária, mas para a previsão de 36 horas. O padrão é desabilitado.

#### Fim de semana

Ative ou desative a previsão do fim de semana. O padrão é habilitado.

#### Fim de semana - Texto detalhado do Outlook

O mesmo que para a previsão diária, mas para a previsão do fim de semana. O padrão é desabilitado.

#### Alertas

Ative ou desative alertas meteorológicos.

#### Mostrar notificação de alerta no nome do local

Se ativado, o nome do local terá 'Alerta meteorológico!' ou "Alertas meteorológicos!" anexado ao nome do local para que a existência de alertas fique visível na tela inicial. O padrão é habilitado.

#### Cor da notificação de alerta

Permite que você altere a cor do texto 'Alerta meteorológico!' anexado ao nome do local, caso seja difícil de ver no skin que você está usando. O padrão é <span style="color:#daa520">Vara de Ouro</span >.

### Mapas

Esta seção permite selecionar quais mapas meteorológicos serão recuperados e como eles serão exibidos.

#### Nível de zoom do mapa

Nível de zoom para mapas meteorológicos. O intervalo é 3-10. O padrão é 7.

#### The Weather Channel - Incluir mapas

Ativa ou desativa a recuperação de mapas meteorológicos do The Weather Channel. O padrão é desabilitado.

#### The Weather Channel - Obter mapa de  &lt;tipo de mapa&gt;

Ativa ou desativa o tipo de mapa meteorológico especificado.

#### OpenWeatherMap - Incluir mapas

Ativa ou desativa a recuperação de mapas meteorológicos do OpenWeatherMap. O padrão é desabilitado.

#### OpenWeatherMap - Chave API

Se você deseja recuperar mapas do OpenWeatherMap, você precisa [inscrever-se para obter uma chave de API gratuita](https://openweathermap.org/appid). Depois de criar uma conta, insira [sua chave](https://home.openweathermap.org/api_keys) aqui.

#### OpenWeatherMap - GObter mapa de  &lt;tipo de mapa&gt;

Ativa ou desativa o tipo de mapa meteorológico especificado.

## Informações para skinners

Todos os valores retornados pelo complemento incluirão suas unidades. Skinners não terão que se preocupar com isso.

NOTA: As condições atuais sempre usarão unidades métricas porque o Kodi as converterá, mas as unidades de previsão diárias e horárias corresponderão às configurações regionais do Kodi.

```
------------------------------
ETIQUETAS DE TEMPO PADRÃO KODI
------------------------------

CURRENT
-------
Current.Location
Current.Condition
Current.Temperature
Current.Wind
Current.WindDirection
Current.Humidity
Current.FeelsLike
Current.DewPoint
Current.UVIndex
Current.ConditionIcon      (por exemplo.'28.png')
Current.FanartCode         (por exemplo.'28')

DAY [0-6]
---------
Day%i.Title
Day%i.HighTemp
Day%i.LowTemp
Day%i.Outlook
Day%i.OutlookIcon
Day%i.FanartCode

ALERTS
------
Alerts

WEATHERPROVIDER
----------------
WeatherProvider
WeatherProviderLogo

-----------------------------
ETIQUETAS DE TEMPO ESTENDIDAS
-----------------------------

FORECAST
--------
Forecast.IsFetched
Forecast.City
Forecast.Country
Forecast.Latitude
Forecast.Longitude
Forecast.Updated           (data e hora em que a previsão foi recuperada pelo Weather Channel)


CURRENT
-------
Current.IsFetched
Current.OutlookIcon        (por exemplo.'28.png' - duplicata de Current.ConditionIcon)
Current.Visibility         (distância visível)
Current.Pressure           (pressão do ar)
Current.PressureChange
Current.SeaLevel           (pressão ao nível do mar)
Current.Precipitation      (acumulação na última hora)
Current.Snow               (acumulação na última hora)
Current.Cloudiness         (cobertura de nuvem)
Current.WindGust           (pode não ser fornecido para todos os locais)

TODAY
-----
Today.IsFetched
Today.Sunrise
Today.Sunset

HOURLY [1-24]
-------------
Hourly.IsFetched
Hourly.%i.Time             (por exemplo.'12:00')
Hourly.%i.LongDate         (longo dia da semana. ou seja, "segunda-feira")
Hourly.%i.ShortDate        (dia curto da semana. ou seja, "segunda-feira")
Hourly.%i.Outlook          (por exemplo.'Chuva muito forte')
Hourly.%i.OutlookIcon      (por exemplo.'28.png')
Hourly.%i.FanartCode       (por exemplo.'28')
Hourly.%i.Temperature
Hourly.%i.FeelsLike
Hourly.%i.Humidity
Hourly.%i.Precipitation    (probabilidade de precipitação)
Hourly.%i.RainDepth        (quantidade de chuva prevista para esta hora)
Hourly.%i.SnowDepth        (profundidade de neve prevista para esta hora)
Hourly.%i.WindSpeed
Hourly.%i.WindDirection    (por exemplo.'SSW')
Hourly.%i.WindDegree       (por exemplo.'220°')
Hourly.%i.DewPoint         (não fornecido pela Weather Network, calculado pela fórmula Magnus-Tetens)

DAILY [1-15]
------------
Daily.IsFetched
Daily.%i.Title             (nome bruto do dia da API Weather Channel)
Daily.%i.LongDay           (por exemplo.'Segunda-feira' - pode ser 'Hoje', 'Esta noite' ou 'Amanhã')
Daily.%i.ShortDay          (por exemplo.'Segunda-feira' - pode ser 'Hoje', 'Esta noite' ou 'Amanhã')
Daily.%i.LongDate          (dia do mês - fornecido apenas se LongDay não for 'Hoje', 'Esta noite' ou 'Amanhã')
Daily.%i.ShortDate         (dia do mês - fornecido apenas se LongDay não for 'Hoje', 'Esta noite' ou 'Amanhã')
Daily.%i.Outlook           (por exemplo.'Predominantemente nublado')
Daily.%i.OutlookIcon       (por exemplo.'28.png')
Daily.%i.FanartCode        (por exemplo.'28')
Daily.%i.Humidity
Daily.%i.Precipitation     (probabilidade de precipitação)
Daily.%i.HighTemperature   (temperatura mais alta que será alcançada hoje - não fornecida se LongDay for 'Tonight')
Daily.%i.LowTemperature    (temperatura mais baixa que será atingida hoje)
Daily.%i.Narrative         (por exemplo.'Parcialmente nublado. Máximos de 1 a 3C e mínimos de -5 a -3C.')
Daily.%i.WindSpeed
Daily.%i.WindDirection     (por exemplo.'SSW')
Daily.%i.WindDegree        (por exemplo.'220°')
Daily.%i.Cloudiness        (% cobertura)
Daily.%i.UVIndex           (por exemplo.'1 (Baixo)')
Daily.%i.Sunrise
Daily.%i.Sunset
Daily.%i.MoonPhase         (por exemplo.'Quarto crescente')
Daily.%1.MoonPhaseCode     (por exemplo.'WXC')
Daily.%i.Moonrise
Daily.%i.Moonset
Daily.%i.RainDepth         (quantidade de chuva do dia)
Daily.%i.SnowDepth         (profundidade da neve no chão durante o dia)

36-HOUR [1-3]
-------------
36Hour.IsFetched
36Hour.%i.Heading
36Hour.%i.FanartCode
36Hour.%i.TemperatureHeading
36Hour.%i.Temperature
36Hour.%i.FeelsLike
36Hour.%i.Outlook
36Hour.%i.Precipitation
36Hour.%i.Cloudiness

WEEKEND [1-2]
-------------
Weekend.IsFetched
Weekend.%i.LongOutlookDay
Weekend.%i.ShortDay
Weekend.%i.LongDate
Weekend.%i.ShortDate
Weekend.%i.Outlook
Weekend.%i.LongOutlookDay
Weekend.%i.LongOutlookNight
Weekend.%i.OutlookIcon
Weekend.%i.FanartCode
Weekend.%i.HighTemperature
Weekend.%i.LowTemperature
Weekend.%i.WindSpeed
Weekend.%i.WindDirection
Weekend.%i.Rain
Weekend.%i.Precipitation
Weekend.%i.Snow
Weekend.%i.ChancePrecipitation
Weekend.%i.Humidity
Weekend.%i.Cloudiness

ALERTS [1-10]
-------------
Alerts.IsFetched
Alerts.%i.Status           (o mesmo que Severity)
Alerts.%i.MessageType
Alerts.%i.Category
Alerts.%i.Severity
Alerts.%i.Certainty
Alerts.%i.Urgency
Alerts.%i.Headline
Alerts.%i.Response
Alerts.%i.Significance
Alerts.%i.StartDate
Alerts.%i.EndDate
Alerts.%i.Description
Alerts.%i.Message          (o mesmo que Description)
Alerts.%i.Instruction

MAP [1-5]
---------
Map.IsFetched
Map.%i.Area
Map.%i.Layer
Map.%i.Heading
Map.%i.Legend
```