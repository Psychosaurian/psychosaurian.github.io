# Elemental Weather (weather.elemental)

Componente aggiuntivo del fornitore di servizi meteo Kodi per The Weather Channel con copertura mondiale corrente, giornaliera (3, 5, 7, 10 o 15 giorni), oraria (2, 3, 10 o 15 ore), 36 ore (sta mattina, stasera , domani mattina o stasera, domani mattina, domani sera) e le previsioni del fine settimana. Può anche fornire mappe meteorologiche The Weather Channel e/o OpenWeatherMap. Sono disponibili anche avvisi e allerte meteo.

## Perché usare Elemental Weather?

Dal rilascio di Kodi Matrix, che non funzionerebbe più con i vecchi fornitori di servizi meteorologici di Kodi Leia e precedenti, non sono stati presenti componenti aggiuntivi di fornitori di servizi meteorologici con una buona copertura mondiale. La maggior parte degli utenti ha optato per Multi Weather che combina le previsioni di Yahoo, Weatherbit e OpenWeatherMap, ma la copertura previsionale delle aree meno popolate è ancora scarsa nonostante le molteplici fonti. Sebbene le skin Kodi spesso supportino periodi di previsione aggiuntivi oltre a quelli orari e giornalieri, nessuno dei fornitori meteo disponibili nei repository ufficiali di Kodi restituisce tutti i tipi di previsioni che sono in grado di visualizzare. Inoltre, sebbene Multi Weather possa recuperare mappe meteorologiche da OpenWeatherMap, nessuno di loro offre mappe da The Weather Channel, che includono mappe satellitari e RADAR, nessuna delle quali disponibile da OpenWeatherMap.

Se desideri la copertura mondiale, la gamma di periodi di previsione e le mappe disponibili da The Weather Channel, allora desideri Elemental Weather.

## Requisiti

Questo componente aggiuntivo richiede Kodi 19.0 (Matrix) o successivo. Le mappe meteorologiche di Weather Channel sono integrate, ma se desideri anche le mappe OpenWeatherMap dovrai registrarti per una chiave API OpenWeatherMap gratuita (dettagli di seguito).

## Supporto per la pelle

Molte skin Kodi popolari trattano il tempo come un ripensamento. Sebbene la maggior parte lo faccia, alcuni non mostrano affatto il tempo e quelli che lo fanno spesso mostrano solo le condizioni attuali e le previsioni giornaliere e orarie. Elemental Weather è stato progettato per fornire tutti gli attributi di previsione estesi forniti da tutti i fornitori di servizi meteorologici disponibili nei repository ufficiali di Kodi, il che significa che dovrebbe funzionare con qualsiasi skin popolare, indipendentemente dal fornitore di servizi meteorologici per cui è stata ottimizzata.

Come accennato in precedenza, Elemental Weather fornisce una gamma completa di periodi e tipi di previsioni, ma a seconda della skin Kodi che stai utilizzando alcune o tutte queste previsioni potrebbero non essere disponibili. Inoltre, sebbene Elemental Weather possa fornire previsioni giornaliere fino a 15 giorni in anticipo e previsioni orarie fino a 15 ore, la tua skin Kodi potrebbe non mostrare tutte quelle ore e quei giorni. Ad esempio, è normale che le skin mostrino solo previsioni di sette o dieci giorni, anche se il componente aggiuntivo del fornitore ne restituisce di più.

Elemental Weather restituirà gli avvisi meteo in due formati diversi, ma la tua skin Kodi potrebbe non utilizzarne nessuno, quindi anche se abiliti gli avvisi meteo nelle impostazioni Elemental Weather potresti non vederli.

Se abiliti tutti i tipi di mappe meteorologiche disponibili da The Weather Channel e OpenWeatherMap Elemental Weather può fornire fino a 13 mappe, ma nessuna delle skin più popolari testate ne mostrerebbe più di cinque. Ciò potrebbe cambiare se questo componente aggiuntivo guadagna popolarità, ma per ora la tua unica scelta se desideri un migliore supporto per le mappe è chiedere al tuo sviluppatore di skin preferito di aggiornare le sue skin, imparare a modificare tu stesso la skin o cercare skin in grado di visualizzare più di solo cinque mappe.

## Configurazione

Elemental Weather è altamente configurabile e consente fino a dieci località di previsione. Se la tua skin non supporta tutte le sue funzionalità puoi disabilitarle singolarmente o ridurre il numero di ore o giorni recuperati per ridurre il traffico Internet non necessario. Le impostazioni sono divise in quattro schede...

### Posizioni

Qui puoi inserire fino a dieci località per le quali recuperare le previsioni. Fare clic su qualsiasi riga di ubicazione e inserire una stringa di ricerca. Se inserisci una stringa di ricerca vuota ti verrà chiesto se desideri eliminare la posizione già presente in quello slot.

Quando scegli la posizione che desideri dai risultati della ricerca, ti viene data l'opportunità di modificare il nome della posizione. Una volta accettato il nome di una posizione, l'unico modo per modificarlo è cercare nuovamente quella posizione.

### Generale

#### Risultati della ricerca dettagliati

Se abilitati, i risultati della ricerca della posizione nella scheda precedente includeranno la latitudine/longitudine e il tipo di posizione (ad esempio città/paese/villaggio, punto di interesse, quartiere, ecc.). Se disabilitato, nei risultati di ricerca viene mostrato solo il nome della posizione. L'impostazione predefinita è abilitata.

#### Mostra popup di errore

I fornitori di servizi meteo vengono eseguiti in background e normalmente non interagiscono con l'utente se non attraverso la visualizzazione del meteo. Se questa opzione è abilitata, un popup visualizzerà gli errori sullo schermo e li salverà nel file di registro di Kodi. Se disabilitato, gli errori verranno salvati solo nel file di registro. L'impostazione predefinita è disabilitata.

#### Le precipitazioni di oggi

Ciò consente di impostare il periodo di tempo utilizzato per l'accumulo delle precipitazioni. Le scelte sono: Ultima ora, Ultime 6 ore o Ultime 24 ore. L'impostazione predefinita è 24 ore.

#### La neve di oggi

Come per le Precipitazioni odierne, ma per gli accumuli di neve.

### Previsioni

#### Quotidiano

Seleziona il numero di giorni forniti dalla previsione giornaliera. Le scelte sono 3, 5, 7, 10 o 15 giorni. L'impostazione predefinita è 7 giorni.

#### Quotidiano - Testo dettagliato di Outlook

Se abilitato, ogni giorno includerà una previsione dettagliata delle prospettive. A seconda della skin utilizzata, ciò potrebbe ingombrare eccessivamente lo schermo. Se disabilitato, la prospettiva prevista sarà composta solo da poche parole, come "Sereno" o "Prevalentemente nuvoloso". L'impostazione predefinita è disabilitata.

#### Ogni ora

Seleziona il numero di ore fornite dalla previsione oraria. Le scelte sono 2, 3, 10 o 15 giorni. L'impostazione predefinita è 10 ore.

#### Ogni ora - Testo dettagliato di Outlook

Come per la previsione giornaliera, ma per la previsione oraria. L'impostazione predefinita è disabilitata.

#### 36 ore

Abilita o disabilita la previsione a 36 ore. L'impostazione predefinita è abilitata.

#### 36 ore - Testo dettagliato di Outlook

Come per la previsione giornaliera, ma per la previsione a 36 ore. L'impostazione predefinita è disabilitata.

#### Fine settimana

Abilita o disabilita le previsioni del fine settimana. L'impostazione predefinita è abilitata.

#### Fine settimana - Testo dettagliato di Outlook

Come per le previsioni giornaliere, ma per le previsioni del fine settimana. L'impostazione predefinita è disabilitata.

#### Avvisi

Abilita o disabilita gli avvisi meteo.

#### Mostra notifica di avviso sul nome della posizione

Se abilitato, il nome della posizione avrà "Avviso meteo!" o "Avvisi meteo!" aggiunto al nome della posizione in modo che l'esistenza degli avvisi sia visibile nella schermata principale. L'impostazione predefinita è abilitata.

#### Colore della notifica di avviso

Ti consente di cambiare il colore del testo "Avviso meteo!" aggiunto al nome della posizione nel caso in cui sia difficile da vedere sulla skin che stai utilizzando. L'impostazione predefinita è <span style="color:#daa520">Verga d'oro</span >.

### Mappe

Questa sezione consente di selezionare quali mappe meteorologiche verranno recuperate e come verranno visualizzate.

#### Livello di zoom della mappa

Livello di zoom per le mappe meteorologiche. L'intervallo è 3-10. L'impostazione predefinita è 7.

#### The Weather Channel - Includi mappe

Abilita o disabilita il recupero delle mappe meteorologiche da The Weather Channel. L'impostazione predefinita è disabilitata.

#### The Weather Channel - Ottieni la mappa delle &lt;tipo di mappa&gt;

Abilita o disabilita il tipo di mappa meteorologica specificata.

#### OpenWeatherMap - Includi mappe

Abilita o disabilita il recupero delle mappe meteorologiche da OpenWeatherMap. L'impostazione predefinita è disabilitata.

#### OpenWeatherMap - Chiave API

Se desideri recuperare mappe da OpenWeatherMap devi [registrarti per una chiave API gratuita](https://openweathermap.org/appid). Dopo aver creato un account, inserisci [la tua chiave](https://home.openweathermap.org/api_keys) qui.

#### OpenWeatherMap - Ottieni la mappa delle &lt;tipo di mappa&gt;

Abilita o disabilita il tipo di mappa meteorologica specificata.

## Informazioni per gli skinner

Tutti i valori restituiti dal componente aggiuntivo includeranno le loro unità. Gli skinner non dovranno preoccuparsene.

NOTA: le condizioni attuali utilizzeranno sempre le unità metriche perché Kodi le convertirà, ma le unità di previsione giornaliera e oraria corrisponderanno alle impostazioni regionali di Kodi.

```
--------------------------------
ETICHETTE METEO KODI PREDEFINITE
--------------------------------

CURRENT
-------
Current.Location
Current.Condition
Current.Temperature
Current.Wind
Current.WindDirection
Current.Humidity
Current.FeelsLike
Current.DewPoint
Current.UVIndex
Current.ConditionIcon      (per esempio. '28.png')
Current.FanartCode         (per esempio. '28')

DAY [0-6]
---------
Day%i.Title
Day%i.HighTemp
Day%i.LowTemp
Day%i.Outlook
Day%i.OutlookIcon
Day%i.FanartCode

ALERTS
------
Alerts

WEATHERPROVIDER
----------------
WeatherProvider
WeatherProviderLogo

----------------------
ETICHETTE METEO ESTESE
----------------------

FORECAST
--------
Forecast.IsFetched
Forecast.City
Forecast.Country
Forecast.Latitude
Forecast.Longitude
Forecast.Updated           (data e ora in cui la previsione è stata recuperata da Weather Channel)


CURRENT
-------
Current.IsFetched
Current.OutlookIcon        (per esempio. '28.png' - duplicato di Current.ConditionIcon)
Current.Visibility         (distanza visibile)
Current.Pressure           (pressione dell'aria)
Current.PressureChange
Current.SeaLevel           (pressione al livello del mare)
Current.Precipitation      (accumulo nell'ultima ora)
Current.Snow               (accumulo nell'ultima ora)
Current.Cloudiness         (copertura nuvolosa)
Current.WindGust           (potrebbero non essere forniti per ogni località)

TODAY
-----
Today.IsFetched
Today.Sunrise
Today.Sunset

HOURLY [1-24]
-------------
Hourly.IsFetched
Hourly.%i.Time             (per esempio. '12:00')
Hourly.%i.LongDate         (lungo giorno della settimana. cioè "lunedì")
Hourly.%i.ShortDate        (lungo giorno della settimana. cioè "lun")
Hourly.%i.Outlook          (per esempio. 'Pioggia molto forte')
Hourly.%i.OutlookIcon      (per esempio. '28.png')
Hourly.%i.FanartCode       (per esempio. '28')
Hourly.%i.Temperature
Hourly.%i.FeelsLike
Hourly.%i.Humidity
Hourly.%i.Precipitation    (probabilità di precipitazioni)
Hourly.%i.RainDepth        (quantità di pioggia prevista per quest'ora)
Hourly.%i.SnowDepth        (profondità della neve prevista per quest'ora)
Hourly.%i.WindSpeed
Hourly.%i.WindDirection    (per esempio. 'SSW')
Hourly.%i.WindDegree       (per esempio. '220°')
Hourly.%i.DewPoint         (non fornito da Weather Network, calcolato utilizzando la formula Magnus-Tetens)

DAILY [1-15]
------------
Daily.IsFetched
Daily.%i.Title             (nome del giorno non elaborato dall'API Weather Channel)
Daily.%i.LongDay           (per esempio. "Lunedì" - può essere "Oggi", "Stasera" o "Domani")
Daily.%i.ShortDay          (per esempio. "Lun" - può essere "Oggi", "Stasera" o "Domani")
Daily.%i.LongDate          (giorno del mese - fornito solo se LongDay non è "Oggi", "Stasera" o "Domani")
Daily.%i.ShortDate         (giorno del mese - fornito solo se LongDay non è "Oggi", "Stasera" o "Domani")
Daily.%i.Outlook           (per esempio. 'Prevalentemente nuvoloso')
Daily.%i.OutlookIcon       (per esempio. '28.png')
Daily.%i.FanartCode        (per esempio. '28')
Daily.%i.Humidity
Daily.%i.Precipitation     (probabilità di precipitazioni)
Daily.%i.HighTemperature   (temperatura più alta che sarà raggiunta oggi - non fornita se LongDay è 'Tonight')
Daily.%i.LowTemperature    (temperatura minima che verrà raggiunta oggi)
Daily.%i.Narrative         (per esempio. 'Mix di sole e nuvole. Massime da 1 a 3°C e minime da -5 a -3°C.')
Daily.%i.WindSpeed
Daily.%i.WindDirection     (per esempio. 'SSW')
Daily.%i.WindDegree        (per esempio. '220°')
Daily.%i.Cloudiness        (% di copertura)
Daily.%i.UVIndex           (per esempio. '1 (Basso)')
Daily.%i.Sunrise
Daily.%i.Sunset
Daily.%i.MoonPhase         (per esempio. 'Mezzaluna ceretta')
Daily.%1.MoonPhaseCode     (per esempio. 'WXC')
Daily.%i.Moonrise
Daily.%i.Moonset
Daily.%i.RainDepth         (quantità di pioggia durante la giornata)
Daily.%i.SnowDepth         (profondità della neve sul terreno per la giornata)

36-HOUR [1-3]
-------------
36Hour.IsFetched
36Hour.%i.Heading
36Hour.%i.FanartCode
36Hour.%i.TemperatureHeading
36Hour.%i.Temperature
36Hour.%i.FeelsLike
36Hour.%i.Outlook
36Hour.%i.Precipitation
36Hour.%i.Cloudiness

WEEKEND [1-2]
-------------
Weekend.IsFetched
Weekend.%i.LongOutlookDay
Weekend.%i.ShortDay
Weekend.%i.LongDate
Weekend.%i.ShortDate
Weekend.%i.Outlook
Weekend.%i.LongOutlookDay
Weekend.%i.LongOutlookNight
Weekend.%i.OutlookIcon
Weekend.%i.FanartCode
Weekend.%i.HighTemperature
Weekend.%i.LowTemperature
Weekend.%i.WindSpeed
Weekend.%i.WindDirection
Weekend.%i.Rain
Weekend.%i.Precipitation
Weekend.%i.Snow
Weekend.%i.ChancePrecipitation
Weekend.%i.Humidity
Weekend.%i.Cloudiness

ALERTS [1-10]
-------------
Alerts.IsFetched
Alerts.%i.Status           (uguale a Severity)
Alerts.%i.MessageType
Alerts.%i.Category
Alerts.%i.Severity
Alerts.%i.Certainty
Alerts.%i.Urgency
Alerts.%i.Headline
Alerts.%i.Response
Alerts.%i.Significance
Alerts.%i.StartDate
Alerts.%i.EndDate
Alerts.%i.Description
Alerts.%i.Message          (uguale a Description)
Alerts.%i.Instruction

MAP [1-5]
---------
Map.IsFetched
Map.%i.Area
Map.%i.Layer
Map.%i.Heading
Map.%i.Legend
```