# Elemental Weather (weather.elemental)

Kodi weather provider addon for The Weather Channel with worldwide coverage of current, daily (3, 5, 7, 10, or 15 days), hourly (2, 3, 10, or 15 hours), 36-hour (this morning, tonight, tomorrow morning or tonight, tomorrow morning, tomorrow night), and weekend forecasts. It can also supply The Weather Channel and/or OpenWeatherMap weather maps. Weather alerts and warnings are also available.

## Why use Elemental Weather?

Since the release of Kodi Matrix, which would no longer work with older weather providers from Kodi Leia and earlier, there have been no weather provider addons with good worldwide coverage. Most users have settled on Multi Weather which combines forecasts from Yahoo, Weatherbit, and OpenWeatherMap, but forecast coverage of lower-population areas is still poor despite the multiple sources. While Kodi skins often support additional forecast periods beyond just hourly and daily, none of the weather providers available in the official Kodi repositories return all the forecast types they are capable of displaying. Also, although Multi Weather can retrieve weather maps from OpenWeatherMap, none of them offers maps from The Weather Channel, which include Satellite and RADAR maps, neither of which are available from OpenWeatherMap.

If you want the worldwide coverage, range of forecast periods, and maps available from The Weather Channel then you want Elemental Weather.

## Requirements

This addon requires Kodi 19.0 (Matrix) or later. The Weather Channel weather maps are built in but if you want OpenWeatherMap maps as well you will need to sign up for a free OpenWeatherMap API Key (details below).

## Skin support

Many popular Kodi skins treat weather as an afterthought. Although most do, some don't display weather at all, and those that do often only show the current conditions and daily and hourly forecasts. Elemental Weather has been designed to provide all the extended forecast attributes supplied by all the weather providers available in the Official Kodi Repositories, which means that it should work with any popular skin, regardless of which weather provider that skin was optimized for.

As mentioned earlier, Elemental Weather provides a full range of forecast periods and types, but depending on the Kodi skin you are using some or all of those forecasts may not be available to you. Also, although Elemental Weather can provide daily forecasts up to 15 days ahead and hourly forecasts up to 15 hours, your Kodi skin might not show all those hours and days. For instance, it is common for skins to only show seven or ten day forecasts, even if the provider addon returns more than that.

Elemental Weather will return weather alerts in two different formats but your Kodi skin might not use either of them so even if you enable weather alerts in Elemental Weather settings you may not see them.

If you enable all weather map types available from The Weather Channel and OpenWeatherMap Elemental Weather can provide up to 13 maps, but none of the popular skins tested would show more than five of them. This may change if this addon gains popularity, but for now your only choices if you want better map support is to ask your favorite skin developer to update their skins, learn how to modify the skin yourself, or search for skins capable of displaying more than just five maps.

## Configuration

Elemental Weather is highly configurable, allowing up to ten forecast locations. If your skin doesn't support all its features you can disable them individually or reduce the number of hours or days retrieved to reduce unnecessary Internet traffic. Settings are divided into four tabs...

### Locations

Here you can enter up to ten locations to retrieve forecasts for. Click on any location line and enter a search string. If you enter an empty search string you are asked if you want to delete the location already in that slot.

When you choose a location you want from the search results you are given an opportunity to edit the location name. Once you have accepted a location name the only way to change it is to search for that location again.

### General

#### Detailed Search Results

If enabled the location search results on the previous tab will include the latitude/longitude and the location type (i.e. city/town/village, point of interest, neighborhood, etc.). If disabled only the location name is shown in search results. Default is enabled.

#### Show Error Popups

Weather providers run in the background and normally don't interact with the user except through the weather display. If this option is enabled a popup will display errors on screen and save them to the Kodi log file. If disabled then errors are only saved in the log file. Default is disabled.

#### Today's Precipitation

This allows you to set the time period used for precipitation accumulation. Choices are last hour, last 6 hours, or last 24 hours. Default is 24 hours.

#### Today's Snow

Same as for Today's Precipitation, but for snow accumulations.

### Forecasts

#### Daily

Select the number of days provided by the daily forecast. Choices are 3, 5, 7, 10 or 15 days. Default is 7 days.

#### Daily - Detailed Outlook Text

If enabled each day will include a detailed outlook forecast. Depending on the skin you are using this may overly clutter the screen. If disabled the forecasted outlook will just be a few words, such as 'Sunny', or 'Mostly Cloudy'. Default is disabled.

#### Hourly

Select the number of hours provided by the hourly forecast. Choices are 2, 3, 10 or 15 days. Default is 10 hours.

#### Hourly - Detailed Outlook Text

Same as for the Daily forecast, but for the Hourly forecast. Default is disabled.

#### 36-Hour

Enable or disable the 36-hour forecast. Default is enabled.

#### 36-Hour - Detailed Outlook Text

Same as for the Daily forecast, but for the 36-Hour forecast. Default is disabled.

#### Weekend

Enable or disable the Weekend forecast. Default is enabled.

#### Weekend - Detailed Outlook Text

Same as for the Daily forecast, but for the Weekend forecast. Default is disabled.

#### Alerts

Enable or disable Weather Alerts.

#### Show alert notification on location name

If enabled the location name will have 'Weather Alert!' or "Weather Alerts!" appended to the location name so the existence of alerts is visible on the home screen. Default is enabled.

#### Alert notification color

Allows you to change the color of the 'Weather Alert!" text appended to the location name in case it is hard to see on the skin you are using. Default is <span style="color:#daa520">Goldenrod</span>.

### Maps

This section allows you to select which weather maps will be retrieved and how they are displayed.

#### Map Zoom Level

Zoom level for weather maps. Range is 3-10. Default is 7.

#### The Weather Channel - Include Maps

Enables or disables retrieval of weather maps from The Weather Channel. Default is disabled.

#### The Weather Channel - Get &lt;maptype&gt; Map

Enables or disables the specified weather map type.

#### OpenWeatherMap - Include Maps

Enables or disables retrieval of weather maps from OpenWeatherMap. Default is disabled.

#### OpenWeatherMap - API Key

If you want to retrieve maps from OpenWeatherMap you need to [sign up for a free API key](https://openweathermap.org/appid). Once you have created an account enter [your key](https://home.openweathermap.org/api_keys) here.

#### OpenWeatherMap - Get &lt;maptype&gt; Map

Enables or disables the specified weather map type.

## Information for skinners

All values returned by the addon will include their units.
Skinners won't have to bother with it.

NOTE: Current conditions will always use metric units because Kodi will
      convert them but daily and hourly forecast units will match Kodi
      regional settings.

```
---------------------------
DEFAULT KODI WEATHER LABELS
---------------------------

CURRENT
-------
Current.Location
Current.Condition
Current.Temperature
Current.Wind
Current.WindDirection
Current.Humidity
Current.FeelsLike
Current.DewPoint
Current.UVIndex
Current.ConditionIcon      (eg. '28.png')
Current.FanartCode         (eg. '28')

DAY [0-6]
---------
Day%i.Title
Day%i.HighTemp
Day%i.LowTemp
Day%i.Outlook
Day%i.OutlookIcon
Day%i.FanartCode

ALERTS
------
Alerts

WEATHERPROVIDER
----------------
WeatherProvider
WeatherProviderLogo

-----------------------
EXTENDED WEATHER LABELS
-----------------------

FORECAST
--------
Forecast.IsFetched
Forecast.City
Forecast.Country
Forecast.Latitude
Forecast.Longitude
Forecast.Updated           (date and time the forecast was retrieved by Weather Channel)


CURRENT
-------
Current.IsFetched
Current.OutlookIcon        (eg. '28.png' - duplicate of Current.ConditionIcon)
Current.Visibility         (visible distance)
Current.Pressure           (air pressure)
Current.PressureChange
Current.SeaLevel           (pressure at sealevel)
Current.Precipitation      (accumulation over last hour)
Current.Snow               (accumulation over last hour)
Current.Cloudiness         (cloud coverage)
Current.WindGust           (may not be supplied for every location)

TODAY
-----
Today.IsFetched
Today.Sunrise
Today.Sunset

HOURLY [1-24]
-------------
Hourly.IsFetched
Hourly.%i.Time             (eg. '12:00')
Hourly.%i.LongDate         (long day of week. i.e. "Monday")
Hourly.%i.ShortDate        (short day of week. i.e. "Mon")
Hourly.%i.Outlook          (eg. 'Very heavy rain')
Hourly.%i.OutlookIcon      (eg. '28.png')
Hourly.%i.FanartCode       (eg. '28')
Hourly.%i.Temperature
Hourly.%i.FeelsLike
Hourly.%i.Humidity
Hourly.%i.Precipitation    (probability of precipitation)
Hourly.%i.RainDepth        (amount of rain predicted for this hour)
Hourly.%i.SnowDepth        (depth of snow predicted for this hour)
Hourly.%i.WindSpeed
Hourly.%i.WindDirection    (eg. 'SSW')
Hourly.%i.WindDegree       (eg. '220°')
Hourly.%i.DewPoint         (not supplied by Weather Network, calculated using the Magnus-Tetens formula)

DAILY [1-15]
------------
Daily.IsFetched
Daily.%i.Title             (raw day name from Weather Channel API)
Daily.%i.LongDay           (eg. 'Monday' - may be 'Today', 'Tonight', or 'Tomorrow')
Daily.%i.ShortDay          (eg. 'Mon' - may be 'Today', 'Tonight', or 'Tomorrow')
Daily.%i.LongDate          (day of month - only supplied if LongDay not 'Today', 'Tonight', or 'Tomorrow')
Daily.%i.ShortDate         (day of month - only supplied if LongDay not 'Today', 'Tonight', or 'Tomorrow')
Daily.%i.Outlook           (eg. 'Mostly Cloudy')
Daily.%i.OutlookIcon       (eg. '28.png')
Daily.%i.FanartCode        (eg. '28')
Daily.%i.Humidity
Daily.%i.Precipitation     (probability of precipitation)
Daily.%i.HighTemperature   (highest temperature that will be reached today - not supplied if LongDay is 'Tonight')
Daily.%i.LowTemperature    (lowest temperature that will be reached today)
Daily.%i.Narrative         (eg. 'Mix of sun and clouds. Highs 1 to 3C and lows -5 to -3C.')
Daily.%i.WindSpeed
Daily.%i.WindDirection     (eg. 'SSW')
Daily.%i.WindDegree        (eg. '220°')
Daily.%i.Cloudiness        (% coverage)
Daily.%i.UVIndex           (eg. '1 (Low)')
Daily.%i.Sunrise
Daily.%i.Sunset
Daily.%i.MoonPhase         (eg. 'Waxing Crescent')
Daily.%1.MoonPhaseCode     (eg. 'WXC')
Daily.%i.Moonrise
Daily.%i.Moonset
Daily.%i.RainDepth         (amount of rainfall for the day)
Daily.%i.SnowDepth         (depth of snow on the ground for the day)

36-HOUR [1-3]
-------------
36Hour.IsFetched
36Hour.%i.Heading
36Hour.%i.FanartCode
36Hour.%i.TemperatureHeading
36Hour.%i.Temperature
36Hour.%i.FeelsLike
36Hour.%i.Outlook
36Hour.%i.Precipitation
36Hour.%i.Cloudiness

WEEKEND [1-2]
-------------
Weekend.IsFetched
Weekend.%i.LongOutlookDay
Weekend.%i.ShortDay
Weekend.%i.LongDate
Weekend.%i.ShortDate
Weekend.%i.Outlook
Weekend.%i.LongOutlookDay
Weekend.%i.LongOutlookNight
Weekend.%i.OutlookIcon
Weekend.%i.FanartCode
Weekend.%i.HighTemperature
Weekend.%i.LowTemperature
Weekend.%i.WindSpeed
Weekend.%i.WindDirection
Weekend.%i.Rain
Weekend.%i.Precipitation
Weekend.%i.Snow
Weekend.%i.ChancePrecipitation
Weekend.%i.Humidity
Weekend.%i.Cloudiness

ALERTS [1-10]
-------------
Alerts.IsFetched
Alerts.%i.Status           (same as Severity)
Alerts.%i.MessageType
Alerts.%i.Category
Alerts.%i.Severity
Alerts.%i.Certainty
Alerts.%i.Urgency
Alerts.%i.Headline
Alerts.%i.Response
Alerts.%i.Significance
Alerts.%i.StartDate
Alerts.%i.EndDate
Alerts.%i.Description
Alerts.%i.Message          (same as Description)
Alerts.%i.Instruction

MAP [1-5]
---------
Map.IsFetched
Map.%i.Area
Map.%i.Layer
Map.%i.Heading
Map.%i.Legend
```