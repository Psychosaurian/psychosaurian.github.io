import sys
from urllib.parse import parse_qs
import json

from resources.lib.maps import Maps

if (__name__ == "__main__"):

    Maps(json.loads(parse_qs(sys.argv[1])['json'][0])).run()
