import json
from math import radians, asinh, tan, pi
from xbmc import Monitor, getRegion, log, LOGERROR
from threading import Thread
from requests import get
from xbmcaddon import Addon
from xbmcvfs import translatePath
from xbmcgui import Window, Dialog
from os.path import join, isfile, exists, getmtime
from os import remove, makedirs, environ
from io import BytesIO
from PIL import Image
import arrow
import glob
from time import sleep

# ---If true caught but unhandled exceptions will launch the web_pdb debugger
DEBUG_EXCEPTIONS = environ.get('DEBUG_KODI_EXCEPTIONS', 'no').lower() == 'yes'

TWC_PRODUCTSET_URL = 'https://api.weather.com/v3/TileServer/series/productSet?filter={filter}&apiKey='
TWC_LAYER_URL = 'https://api.weather.com/v3/TileServer/tile/{product}?ts={ts}&xyz={x}:{y}:{z}&apiKey='
OSM_URL = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
OWM_URL = 'https://tile.openweathermap.org/map/{layer}/{z}/{x}/{y}.png?appid='

IMMEDIATE_TILE_RETRIES = 3
DELAYED_TILE_RETRIES   = 3
TRY_DELAY              = 15

class MapWorkerMonitor(Monitor):
    def __init__(self, *args, **kwargs):
        Monitor.__init__(self)

class Maps:

    def __enter__(self):

        return self

    def __init__(self, json):

        self.__xyz = self.__toSlippy(json['zoom'], json['latitude'], json['longitude'])
        self.__twcApiKey = json['twcKey']
        self.__owmApiKey = json['owmKey']
        self.__twcLayers = json['twc'] if 'twc' in json else None
        self.__owmLayers = json['owm'] if 'owm' in json else None
        self.__showErrorPopups = json['showErrorPopups']

    def __toSlippy(self, zoom, latitude, longitude):

        latitudeRadians = radians(latitude)

        # ---'n' is the number of tiles along each axis of the map
        n = 1 << zoom

        xLocation = (longitude + 180.0) / 360.0 * n
        xTile = int(xLocation)
        yLocation = (1.0 - asinh(tan(latitudeRadians)) / pi) / 2.0 * n
        yTile = int(yLocation)

        # ---How many pixels the layers need to be shifted to display the target coordinates dead center
        xPixelOffset = 128 - round((xLocation % 1) * 256)
        yPixelOffset = 128 - round((yLocation % 1) * 256)

        return {'x': xTile, 'y': yTile, 'z': zoom, 'xPixelOffset': xPixelOffset, 'yPixelOffset': yPixelOffset}

    def run(self):

        worker = MapWorker( self.__showErrorPopups, self.__xyz, self.__twcApiKey, self.__twcLayers, self.__owmApiKey, self.__owmLayers)
        worker.run()

class MapWorker(Thread):

    def __enter__(self):
        return self

    def __init__(self, showErrorPopups, xyz, twcApiKey, twcLayers, owmApiKey, owmLayers):
        
        self.__addon = Addon()
        self.__weatherWindow = Window(12600)

        self.__showErrorPopups = showErrorPopups
        self.__xyz = xyz
        self.__x = xyz['x']
        self.__y = xyz['y']
        self.__z = xyz['z']
        self.__twcLayers = twcLayers
        self.__owmLayers = owmLayers
        self.__twcProductSetUrl = TWC_PRODUCTSET_URL + twcApiKey
        self.__twcLayertUrl = TWC_LAYER_URL + twcApiKey
        self.__owmUrl = OWM_URL + owmApiKey
        self.__profile = translatePath(self.__addon.getAddonInfo('profile'))
        self.__headers = {

            'Accept-Encoding': 'gzip',
            "user-agent": "%s/%s (+https://forum.kodi.tv/showthread.php?tid=207110)" % (self.__addon.getAddonInfo('id'), self.__addon.getAddonInfo('version'))
        }

        # ---Calculate how which tiles we need and haw many pixels to offset the layers to put the location dead center
        xPixelOffset = self.__xyz['xPixelOffset']
        yPixelOffset = self.__xyz['yPixelOffset']

        if xPixelOffset < 0:
            self.__xTileRange = range(self.__x -1, self.__x +3)
            self.__startX = xPixelOffset
        elif xPixelOffset > 0:
            self.__xTileRange = range(self.__x -2, self.__x +2)
            self.__startX = xPixelOffset - 256
        else:
            self.__xTileRange = range(self.__x -1, self.__x +2)
            self.__startX = 0

        # ---There are 78 extra pixels top and bottom before we have to retrieve extra tiles
        if yPixelOffset > 78:
            self.__yTileRange = range(self.__y -2, self.__y +2)
            self.__startY = yPixelOffset - 78 - 256 
        elif yPixelOffset < -78:
            self.__yTileRange = range(self.__y -1, self.__y +3)
            self.__startY = yPixelOffset - 78
        else:
            self.__yTileRange = range(self.__y -1, self.__y +2)
            self.__startY = yPixelOffset - 78


        # ---Make sure the map file paths exist
        for layer in ('clouds', 'precipitation', 'pressure', 'temp', 'wind'):
            try:
                makedirs(join(self.__profile, 'maps', 'owm', layer))
            except FileExistsError:
                pass

        for layer in ('feelsLike', 'precip24hr', 'radar', 'sat', 'satrad', 'temp', 'uv', 'windSpeed'):
            try:
                makedirs(join(self.__profile, 'maps', 'twc', layer))
            except FileExistsError:
                pass


        self.__monitor = MapWorkerMonitor()
        Thread.__init__(self)

    def __getLayer(self, layerUrl):

        # ---Kodi doesn't display maps square, the aspect ratio is about 768:612
        map = Image.new("RGBA", (768, 612), None)

        tileY = self.__startY

        for y in self.__yTileRange:

            tileX = self.__startX

            for x in self.__xTileRange:

                url = layerUrl.format(x = x, y = y, z = self.__z)

                delayedTry = 0
                while True:

                    immediateTry = 0
                    while immediateTry < IMMEDIATE_TILE_RETRIES:
                        try:
                            response = get(url, headers = self.__headers, timeout=15)
                            break
                        except:
                            immediateTry += 1

                    if immediateTry < IMMEDIATE_TILE_RETRIES:
                        # ---Success
                        break

                    delayedTry += 1

                    if delayedTry < DELAYED_TILE_RETRIES:

                        # ---Wait a bit before we try again
                        sleep(TRY_DELAY)

                    else:
                        # ---Give up
                        break

                tile = Image.open(BytesIO(response.content))

                map.paste(tile, (tileX, tileY))

                tileX += 256

            tileY += 256

        return map

    def run(self):

        #
        # To avoid downloading basemaps over and over we only download one if it doesn't
        # already exist in the maps directory, but we download anyway if the extant one
        # is over 10 days old. Just deleting every basemap over 10 days old in a loop
        # here instead of doing it for each basemap before we use it ensures that
        # orphaned location basemaps (the location was removed from settings) will
        # eventually be cleaned up too.
        #

        nowTimestamp = arrow.now().timestamp()

        files = glob.glob(join(self.__profile, 'maps', 'basemap*'))
        for file in files:
            if ((nowTimestamp - getmtime(file)) > 864000):
                remove(file)

        # ---Every location and zoom needs a unique filename else Kodi won't reload the base map when location is changed
        baseMapFile = join(self.__profile, 'maps', 'basemap-%i-%i-%i-%03i%03i.png' % (

            self.__xyz['x'],
            self.__xyz['y'],
            self.__xyz['z'],
            self.__xyz['xPixelOffset'] + 128,
            self.__xyz['yPixelOffset'] + 128
        ))

        try:
            # ---We only need to download the basemap fif we don't already have it
            if not isfile(baseMapFile):

                baseMap = self.__getLayer(OSM_URL)

                if not baseMap:

                    log(self.__addon.getLocalizedString(32102) % self.__addon.getAddonInfo('id'), LOGERROR)

                    if self.__showErrorPopups:
                        Dialog().ok(self.__addon.getAddonInfo('name'), self.__addon.getLocalizedString(32101))

                    # ---Couldn't get the basemap so don't bother trying to get any layers
                    return
                
                baseMap.save(baseMapFile)

        except Exception as e:
            if DEBUG_EXCEPTIONS:
                bp()
            raise e

        legendPath = join(self.__addon.getAddonInfo('path'), 'resources', 'graphics')

        layerNum = 1

        # ---TWC layers
        if len(self.__twcLayers) > 0:

            # ---First we need to ask TWC for a list of layer snapshots
            snapshots = self.__getTwcLayerSnapshots()

            for snapshot in snapshots:

                layerType = snapshot['product']
                ts = snapshot['ts']
                layerMapPath = join(self.__profile, 'maps', 'twc', snapshot['layer'])

                # ---Have to combine XYZ, location offset, and timeslice into file name to ensure Kodi will load changes
                layerMapFile = join(layerMapPath, '%s-%i-%i-%i-%03i%03i-%s.png' % (
                    
                    layerType, 
                    self.__x, 
                    self.__y, 
                    self.__z,
                    self.__xyz['xPixelOffset'] + 128,
                    self.__xyz['yPixelOffset'] + 128,
                    ts
                ))

                # ---Did we already download this layer snapshot?
                if not exists(layerMapFile):

                    # ---No we don't have this snapshot yet, clear any files already in the layer directory
                    while True:
                        try:
                            files = glob.glob(join(layerMapPath,'*'))
                            for file in files:
                                remove(file)

                            # ---Successfully deleted all files
                            break

                        except FileNotFoundError as e:
                            
                            # ---File must have been deleted already, do nothing
                            pass
                        
                        except PermissionError as e:
                            # ---If errorno is 13 the file must have been in use so just proceed to the next file
                            if e.args[0] != 13:
                                # ---Not errorno 13, pass the exception up
                                if DEBUG_EXCEPTIONS:
                                    bp()
                                raise e

                        except Exception as e:

                            if DEBUG_EXCEPTIONS:
                                bp()
                            raise e
                        
                    # ---Wind speed tiles are masked over water if we don't add 'NM' to the end of the product name for the API call
                    layerUrl = self.__twcLayertUrl.format(product='windSpeedNM' if layerType == 'windSpeed' else layerType, ts=snapshot['ts'], x='{x}', y='{y}', z= '{z}')
                    layerMap = self.__getLayer(layerUrl)

                    if not layerMap:
                        # ---Failed to get the layer( 
                        log(self.__addon.getLocalizedString(32104) % (self.__addon.getAddonInfo('id'), layerType), LOGERROR)

                        if self.__showErrorPopups:
                            Dialog().ok(self.__addon.getAddonInfo('name'), self.__addon.getLocalizedString(32103) % snapshot['name'])

                        # ---Try the next layer
                        next

                    layerMap.save(layerMapFile)

                self.__weatherWindow.setProperty('Map.%i.Area' % layerNum, baseMapFile)
                self.__weatherWindow.setProperty('Map.%i.Layer' % layerNum, layerMapFile)
                self.__weatherWindow.setProperty('Map.%i.Heading' % layerNum,  snapshot['name'])

                if layerType == 'uv':
                    self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'twc-uv.png'))
                elif layerType == 'temp' or layerType == 'feelsLike':
                    self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'twc-temp-f.png' if getRegion('tempunit') == '°F' else 'twc-temp-c.png'))
                if layerType == 'windSpeed':
                    speedUnits = getRegion('speedunit')
                    if speedUnits == 'Beaufort':
                        self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'twc-windSpeed-bft.png'))
                    elif getRegion('speedunit') in ('m/min', 'ft/h', 'ft/min', 'ft/s', 'mph', 'inch/s', 'yard/s', 'Furlong/Fortnight'):
                        self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'twc-windSpeed-mph.png'))
                    else:
                        self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'twc-windSpeed-kph.png'))
                elif layerType == 'precip1hr' or layerType == 'precip24hr':
                    if getRegion('speedunit') in ('m/min', 'ft/h', 'ft/min', 'ft/s', 'mph', 'inch/s', 'yard/s', 'Furlong/Fortnight'):
                        self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'twc-precip-in.png'))
                    else:
                        self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'twc-precip-mm.png'))

                layerNum += 1

        # ---OWM layers
        for layer in self.__owmLayers:

            # ---Save a timestamp to use when generating layer file names
            now = arrow.now().format('YYYY-MM-DD-HH-mm-ss')

            try:
                layerType = layer['layer']

                # ---X, Y, and Z must be supplied in the format call but need to stay the same to be formatted again in __getLayer()
                layerMap  = self.__getLayer(self.__owmUrl.format(layer = layerType, x = '{x}', y = '{y}', z = '{z}'))

                if not layerMap:
                    # ---Failed to get the layer( 
                    log(self.__addon.getLocalizedString(32106) % (self.__addon.getAddonInfo('id'), layerType), LOGERROR)

                    if self.__showErrorPopups:
                        Dialog().ok(self.__addon.getAddonInfo('name'), self.__addon.getLocalizedString(32105) % layer['name'])

                    # ---Try the next layer
                    next

                layerMapPath = join(self.__profile, 'maps', 'owm', layerType)

                # ---Clear any files already in the layer directory
                while True:
                    try:
                        files = glob.glob(join(layerMapPath,'*'))
                        for file in files:
                            remove(file)

                        break

                    except FileNotFoundError as e:
                        
                        # ---File must have been deleted already, do nothing
                        pass

                    except PermissionError as e:
                        # ---If errorno is 13 the file must have been in use so just proceed to the next file
                        if e.args[0] != 13:
                            # ---Not errorno 13, pass the exception up
                            raise e

                layerMapFile = join(layerMapPath, '%s-%s.png' % (layerType, now))
                layerMap.save(layerMapFile)

                self.__weatherWindow.setProperty('Map.%i.Area' % layerNum, baseMapFile)
                self.__weatherWindow.setProperty('Map.%i.Layer' % layerNum, layerMapFile)
                self.__weatherWindow.setProperty('Map.%i.Heading' % layerNum,  layer['name'])

                # TODO: Add extra legend types for different units
                if layerType == 'clouds':
                    self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'owm-clouds.png'))
                elif layerType == 'pressure':
                    self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'owm-press.png'))
                elif layerType == 'temp':
                    self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'owm-temp-f.png' if getRegion('tempunit') == '°F' else 'owm-temp-c.png'))
                elif layerType == 'wind':
                    speedUnits = getRegion('speedunit')
                    if speedUnits == 'Beaufort':
                        self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'owm-wind-bft.png'))
                    elif getRegion('speedunit') in ('m/min', 'ft/h', 'ft/min', 'ft/s', 'mph', 'inch/s', 'yard/s', 'Furlong/Fortnight'):
                        self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'owm-wind-mi.png'))
                    else:
                        self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'owm-wind-kmh.png'))
                elif layerType == 'precipitation':
                    if getRegion('speedunit') in ('m/min', 'ft/h', 'ft/min', 'ft/s', 'mph', 'inch/s', 'yard/s', 'Furlong/Fortnight'):
                        self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'owm-precip-in.png'))
                    else:
                        self.__weatherWindow.setProperty('Map.%i.Legend' % layerNum, join(legendPath, 'owm-precip-mm.png'))

                layerNum += 1

            except Exception as e:
                if DEBUG_EXCEPTIONS:
                    bp()
                raise e

            pass

        # ---Clear unused layer forecasts
        for num in range(layerNum, 21):
            self.__weatherWindow.clearProperty('Map.%i.Area' % num)
            self.__weatherWindow.clearProperty('Map.%i.Layer' % num)
            self.__weatherWindow.clearProperty('Map.%i.Heading' % num)
            self.__weatherWindow.clearProperty('Map.%i.Legend' % num)

        # ---Set Map.IsFetched
        if layerNum > 1:
            self.__weatherWindow.setProperty('Map.IsFetched', 'true')
        else:
            self.__weatherWindow.clearProperty('Map.IsFetched')


    def __getTwcLayerSnapshots(self):

        filter = self.__twcLayers[0]['layer']

        # ---Build a product filter for the TWC API call
        for layer in self.__twcLayers[1:]:
            filter += ',' + layer['layer']

        url = self.__twcProductSetUrl.format(filter=filter)

        snapshots = []

        try:

            # ---Ask TWC for a series of layer snapshots for each product
            result = get(url, timeout=15)

            seriesJson = json.loads(result.content)['seriesInfo']

            for layer in self.__twcLayers:

                product = layer['layer']

                # ---Only fetch this layer if we got a series for it
                if product in seriesJson:
                    # ---Series '0' is the latest snapshot
                    snapshots.append({'layer': layer['layer'], 'name': layer['name'], 'product': product, 'ts': seriesJson[product]['series'][0]['ts']})

            return snapshots
                    
        except Exception as e:

            if DEBUG_EXCEPTIONS:
                bp()
            raise e
